module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./components/alheimsins/Button.js":
/*!*****************************************!*\
  !*** ./components/alheimsins/Button.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/* harmony default export */ __webpack_exports__["default"] = (props => {
  const propTypes = {
    onClick: props.onClick,
    disabled: props.disabled,
    value: props.value,
    type: props.type || 'button',
    name: props.name,
    autoFocus: props.autoFocus
  };
  return __jsx("p", {
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["4294457227", [props.width || '200px', props.height || '50px', props.border || '1px solid black', props.fontSize || '12px', props.color || 'white', props.background || 'black']]])
  }, __jsx("input", _extends({}, propTypes, {
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["4294457227", [props.width || '200px', props.height || '50px', props.border || '1px solid black', props.fontSize || '12px', props.color || 'white', props.background || 'black']]]) + " " + (propTypes && propTypes.className != null && propTypes.className || "")
  })), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
    id: "4294457227",
    dynamic: [props.width || '200px', props.height || '50px', props.border || '1px solid black', props.fontSize || '12px', props.color || 'white', props.background || 'black']
  }, `input.__jsx-style-dynamic-selector{width:${props.width || '200px'};height:${props.height || '50px'};border:${props.border || '1px solid black'};font-size:${props.fontSize || '12px'};text-transform:uppercase;-webkit-transition:all 200ms;transition:all 200ms;color:${props.color || 'white'};background:${props.background || 'black'};border-radius:5px;cursor:pointer;-webkit-appearance:none;}input.__jsx-style-dynamic-selector:disabled{background:#eaeaea;color:#cccccc;border-color:white;}
/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXEJ1dHRvbi5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFjUyxBQUdnRCxBQWFoQixtQkFDTCxjQUNLLEVBZGlCLGlCQWV0QyxtQkFkc0Msb0NBQ0csdUNBQ2QseUJBQ0osa0RBQ2MsbUNBQ0ssd0NBQ3RCLGtCQUNILGVBQ1Msd0JBQzFCIiwiZmlsZSI6Ikc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXEJ1dHRvbi5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IChwcm9wcykgPT4ge1xuICBjb25zdCBwcm9wVHlwZXMgPSB7XG4gICAgb25DbGljazogcHJvcHMub25DbGljayxcbiAgICBkaXNhYmxlZDogcHJvcHMuZGlzYWJsZWQsXG4gICAgdmFsdWU6IHByb3BzLnZhbHVlLFxuICAgIHR5cGU6IHByb3BzLnR5cGUgfHwgJ2J1dHRvbicsXG4gICAgbmFtZTogcHJvcHMubmFtZSxcbiAgICBhdXRvRm9jdXM6IHByb3BzLmF1dG9Gb2N1c1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8cD5cbiAgICAgIDxpbnB1dCB7Li4ucHJvcFR5cGVzfSAvPlxuICAgICAgPHN0eWxlIGpzeD5cbiAgICAgICAge2BcbiAgICAgICAgICBpbnB1dCB7XG4gICAgICAgICAgICB3aWR0aDogJHtwcm9wcy53aWR0aCB8fCAnMjAwcHgnfTtcbiAgICAgICAgICAgIGhlaWdodDogJHtwcm9wcy5oZWlnaHQgfHwgJzUwcHgnfTtcbiAgICAgICAgICAgIGJvcmRlcjogJHtwcm9wcy5ib3JkZXIgfHwgJzFweCBzb2xpZCBibGFjayd9O1xuICAgICAgICAgICAgZm9udC1zaXplOiAke3Byb3BzLmZvbnRTaXplIHx8ICcxMnB4J307XG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgICAgICAgdHJhbnNpdGlvbjogYWxsIDIwMG1zO1xuICAgICAgICAgICAgY29sb3I6ICR7cHJvcHMuY29sb3IgfHwgJ3doaXRlJ307XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAke3Byb3BzLmJhY2tncm91bmQgfHwgJ2JsYWNrJ307XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgICAgICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlucHV0OmRpc2FibGVkIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNlYWVhZWE7XG4gICAgICAgICAgICBjb2xvcjogI2NjY2NjYztcbiAgICAgICAgICAgIGJvcmRlci1jb2xvcjogd2hpdGU7XG4gICAgICAgICAgfVxuICAgICAgICBgfVxuICAgICAgPC9zdHlsZT5cbiAgICA8L3A+XG4gIClcbn1cbiJdfQ== */
/*@ sourceURL=G:\\dev\\ipip\\components\\alheimsins\\Button.js */`));
});

/***/ }),

/***/ "./components/alheimsins/Code.js":
/*!***************************************!*\
  !*** ./components/alheimsins/Code.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;
/* harmony default export */ __webpack_exports__["default"] = (({
  children
}) => __jsx("span", {
  className: "jsx-2777952669" + " " + 'code'
}, children, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "2777952669"
}, ".jsx-2777952669{color:#bd10e0;font-family:Menlo,Monaco,Lucida Console,Liberation Mono,DejaVu Sans Mono,Bitstream Vera Sans Mono,Courier New,monospace,serif;font-size:0.9em;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXENvZGUuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBSU8sQUFFdUIsY0FDa0gsOEhBQ2hILGdCQUNsQiIsImZpbGUiOiJHOlxcZGV2XFxpcGlwXFxjb21wb25lbnRzXFxhbGhlaW1zaW5zXFxDb2RlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgKHsgY2hpbGRyZW4gfSkgPT4gKFxuICA8c3BhbiBjbGFzc05hbWU9J2NvZGUnPlxuICAgIHtjaGlsZHJlbn1cbiAgICA8c3R5bGUganN4PlxuICAgICAge2BcbiAgICAgICAgY29sb3I6ICNiZDEwZTA7XG4gICAgICAgIGZvbnQtZmFtaWx5OiBNZW5sbyxNb25hY28sTHVjaWRhIENvbnNvbGUsTGliZXJhdGlvbiBNb25vLCBEZWphVnUgU2FucyBNb25vLEJpdHN0cmVhbSBWZXJhIFNhbnMgTW9ubyxDb3VyaWVyIE5ldyxtb25vc3BhY2UsIHNlcmlmO1xuICAgICAgICBmb250LXNpemU6IDAuOWVtO1xuICAgICAgYH1cbiAgICA8L3N0eWxlPlxuICA8L3NwYW4+XG4pXG4iXX0= */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\alheimsins\\\\Code.js */")));

/***/ }),

/***/ "./components/alheimsins/Field.js":
/*!****************************************!*\
  !*** ./components/alheimsins/Field.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/* harmony default export */ __webpack_exports__["default"] = (props => __jsx("div", {
  style: _objectSpread({}, props.style),
  className: "jsx-2692660897" + " " + 'field'
}, __jsx("label", {
  htmlFor: props.name,
  className: "jsx-2692660897"
}, props.name.toUpperCase(), ":"), props.children, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "2692660897"
}, ".field.jsx-2692660897{margin-bottom:30px;border-bottom:1px solid #d8d8d8;width:100%;}.field.jsx-2692660897:focus-within,.field.jsx-2692660897:focus{border-bottom:1px solid #000 !important;}label.jsx-2692660897{margin-right:2px;display:inline-block;width:80px;font-size:11px;font-weight:bold;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXEZpZWxkLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQU9PLEFBRzhCLEFBS3FCLEFBR3ZCLGlCQUNJLEVBUlcsbUJBU3JCLEVBSmIsU0FLaUIsRUFUSixXQUNiLEVBU21CLGlCQUNuQiIsImZpbGUiOiJHOlxcZGV2XFxpcGlwXFxjb21wb25lbnRzXFxhbGhlaW1zaW5zXFxGaWVsZC5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IChwcm9wcykgPT4gKFxuICA8ZGl2IGNsYXNzTmFtZT0nZmllbGQnIHN0eWxlPXt7IC4uLnByb3BzLnN0eWxlIH19PlxuICAgIDxsYWJlbCBodG1sRm9yPXtwcm9wcy5uYW1lfT5cbiAgICAgIHtwcm9wcy5uYW1lLnRvVXBwZXJDYXNlKCl9OlxuICAgIDwvbGFiZWw+XG4gICAge3Byb3BzLmNoaWxkcmVufVxuICAgIDxzdHlsZSBqc3g+XG4gICAgICB7YFxuICAgICAgICAuZmllbGQge1xuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkOGQ4ZDg7XG4gICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIH1cbiAgICAgICAgLmZpZWxkOmZvY3VzLXdpdGhpbiwgLmZpZWxkOmZvY3VzIHtcbiAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzAwMCAhaW1wb3J0YW50O1xuICAgICAgICB9XG4gICAgICAgIGxhYmVsIHtcbiAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDJweDtcbiAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgICAgd2lkdGg6IDgwcHg7XG4gICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xuICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICB9XG4gICAgICBgfVxuICAgIDwvc3R5bGU+XG4gIDwvZGl2PlxuKVxuIl19 */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\alheimsins\\\\Field.js */")));

/***/ }),

/***/ "./components/alheimsins/Footer.js":
/*!*****************************************!*\
  !*** ./components/alheimsins/Footer.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Link */ "./components/alheimsins/Link.js");
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Logo */ "./components/alheimsins/Logo.js");


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;


const links = [{
  url: 'https://alheimsins.net',
  name: 'alheimsins',
  icon: Object(_Logo__WEBPACK_IMPORTED_MODULE_3__["default"])({
    color: 'white'
  }),
  color: 'white'
}, {
  url: 'https://github.com/alheimsins',
  name: 'github'
}, {
  url: '/about',
  name: 'about',
  target: '_self'
}];
/* harmony default export */ __webpack_exports__["default"] = (() => __jsx("footer", {
  className: "jsx-2551648561"
}, __jsx("div", {
  className: "jsx-2551648561"
}, links.map(link => !link.target ? __jsx("a", {
  key: link.name,
  href: link.url,
  target: "_blank",
  style: {
    color: link.color
  },
  rel: "noopener noreferrer",
  className: "jsx-2551648561"
}, link.icon, link.name) : __jsx(_Link__WEBPACK_IMPORTED_MODULE_2__["default"], {
  key: link.name,
  route: link.url
}, __jsx("a", {
  className: "jsx-2551648561"
}, link.icon, link.name)))), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "2551648561"
}, "a.jsx-2551648561{display:inline-block;text-transform:uppercase;position:relative;-webkit-text-decoration:none;text-decoration:none;color:#666;margin:0;-webkit-transition:all 200ms;transition:all 200ms;margin-left:20px;font-size:12px;}a.jsx-2551648561:after{content:'';height:1px;background:white;position:absolute;pointer-events:none;bottom:-5px;left:0;right:0;opacity:0;-webkit-transform:scale(0,1);-ms-transform:scale(0,1);transform:scale(0,1);-webkit-transition:all 200ms;transition:all 200ms;}a.jsx-2551648561:hover.jsx-2551648561:after{opacity:1;-webkit-transform:scale(1,1);-ms-transform:scale(1,1);transform:scale(1,1);}a.jsx-2551648561:hover{color:white;}footer.jsx-2551648561{grid-area:footer;background:black;color:#666;font-size:12px;height:80px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXEZvb3Rlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFpQ08sQUFHZ0MsQUFXVixBQWFELEFBSUUsQUFHSyxVQU5LLENBYlgsQ0FpQmIsS0FHbUIsSUEvQlEsQ0FZUixZQW9CTixLQW5CTyxNQW9CSCxDQWhDRyxXQWFFLEdBb0JSLElBaENTLFFBaUNSLEtBcEJELFFBVWQsSUFUUyxPQUNDLFFBQ0UsVUFmQyxBQWdCVyxXQWZiLFNBQ1ksWUErQkUsc0NBOUJOLEtBY0ksWUFiTixlQUNqQix1QkFhQSxNQWdCcUIsNkZBQ3JCIiwiZmlsZSI6Ikc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXEZvb3Rlci5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMaW5rIGZyb20gJy4vTGluaydcbmltcG9ydCBMb2dvIGZyb20gJy4vTG9nbydcblxuY29uc3QgbGlua3MgPSBbXG4gIHtcbiAgICB1cmw6ICdodHRwczovL2FsaGVpbXNpbnMubmV0JyxcbiAgICBuYW1lOiAnYWxoZWltc2lucycsXG4gICAgaWNvbjogTG9nbyh7IGNvbG9yOiAnd2hpdGUnIH0pLFxuICAgIGNvbG9yOiAnd2hpdGUnXG4gIH0sXG4gIHtcbiAgICB1cmw6ICdodHRwczovL2dpdGh1Yi5jb20vYWxoZWltc2lucycsXG4gICAgbmFtZTogJ2dpdGh1YidcbiAgfSxcbiAge1xuICAgIHVybDogJy9hYm91dCcsXG4gICAgbmFtZTogJ2Fib3V0JyxcbiAgICB0YXJnZXQ6ICdfc2VsZidcbiAgfVxuXVxuXG5leHBvcnQgZGVmYXVsdCAoKSA9PiAoXG4gIDxmb290ZXI+XG4gICAgPGRpdj5cbiAgICAgIHtcbiAgICAgICAgbGlua3MubWFwKGxpbmsgPT5cbiAgICAgICAgICAhbGluay50YXJnZXRcbiAgICAgICAgICAgID8gPGEga2V5PXtsaW5rLm5hbWV9IGhyZWY9e2xpbmsudXJsfSB0YXJnZXQ9J19ibGFuaycgc3R5bGU9e3sgY29sb3I6IGxpbmsuY29sb3IgfX0gcmVsPSdub29wZW5lciBub3JlZmVycmVyJz57bGluay5pY29ufXtsaW5rLm5hbWV9PC9hPlxuICAgICAgICAgICAgOiA8TGluayBrZXk9e2xpbmsubmFtZX0gcm91dGU9e2xpbmsudXJsfT48YT57bGluay5pY29ufXtsaW5rLm5hbWV9PC9hPjwvTGluaz5cbiAgICAgICAgKVxuICAgICAgfVxuICAgIDwvZGl2PlxuICAgIDxzdHlsZSBqc3g+XG4gICAgICB7YFxuICAgICAgICBhIHtcbiAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICAgICAgICAgIGNvbG9yOiAjNjY2O1xuICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgICB0cmFuc2l0aW9uOiBhbGwgMjAwbXM7XG4gICAgICAgICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICB9XG4gICAgICAgIGE6YWZ0ZXIge1xuICAgICAgICAgIGNvbnRlbnQ6ICcnO1xuICAgICAgICAgIGhlaWdodDogMXB4O1xuICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgICBib3R0b206IC01cHg7XG4gICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICBvcGFjaXR5OiAwO1xuICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMCwgMSk7XG4gICAgICAgICAgdHJhbnNpdGlvbjogYWxsIDIwMG1zO1xuICAgICAgICB9XG4gICAgICAgIGE6aG92ZXI6YWZ0ZXIge1xuICAgICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLCAxKTtcbiAgICAgICAgfVxuICAgICAgICBhOmhvdmVyIHtcbiAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgIH1cbiAgICAgICAgZm9vdGVyIHtcbiAgICAgICAgICBncmlkLWFyZWE6IGZvb3RlcjtcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBibGFjaztcbiAgICAgICAgICBjb2xvcjogIzY2NjtcbiAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgaGVpZ2h0OiA4MHB4O1xuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgfVxuICAgICAgYH1cbiAgICA8L3N0eWxlPlxuICA8L2Zvb3Rlcj5cbilcbiJdfQ== */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\alheimsins\\\\Footer.js */")));

/***/ }),

/***/ "./components/alheimsins/Header.js":
/*!*****************************************!*\
  !*** ./components/alheimsins/Header.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Link */ "./components/alheimsins/Link.js");


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;

/* harmony default export */ __webpack_exports__["default"] = (({
  user,
  info
}) => __jsx("header", {
  className: "jsx-3612939483"
}, __jsx("div", {
  className: "jsx-3612939483" + " " + 'nav-container'
}, __jsx("div", {
  className: "jsx-3612939483" + " " + 'links-container'
}, __jsx(_Link__WEBPACK_IMPORTED_MODULE_2__["default"], {
  route: "/",
  activeClassName: "active"
}, __jsx("a", {
  className: "jsx-3612939483"
}, "HOME")), __jsx(_Link__WEBPACK_IMPORTED_MODULE_2__["default"], {
  route: "/test",
  activeClassName: "active"
}, __jsx("a", {
  className: "jsx-3612939483"
}, "TEST")), __jsx(_Link__WEBPACK_IMPORTED_MODULE_2__["default"], {
  route: "/result",
  activeClassName: "active"
}, __jsx("a", {
  className: "jsx-3612939483"
}, "RESULT")), __jsx(_Link__WEBPACK_IMPORTED_MODULE_2__["default"], {
  route: "/compare",
  activeClassName: "active"
}, __jsx("a", {
  className: "jsx-3612939483"
}, "COMPARE")), __jsx(_Link__WEBPACK_IMPORTED_MODULE_2__["default"], {
  route: "/about",
  activeClassName: "active"
}, __jsx("a", {
  className: "jsx-3612939483"
}, "ABOUT"))), __jsx("div", {
  className: "jsx-3612939483" + " " + 'nav-right'
}, user ? __jsx("span", {
  className: "jsx-3612939483"
}, "logged in as ", __jsx("b", {
  className: "jsx-3612939483"
}, user)) : __jsx("a", {
  href: "/api/login",
  style: {
    color: 'black'
  },
  className: "jsx-3612939483"
}, "LOGIN")), info && __jsx("div", {
  className: "jsx-3612939483" + " " + 'nav-info'
}, info)), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "3612939483"
}, "header.jsx-3612939483{grid-area:header;justify-self:center;background:white;margin:auto;padding:25px;max-width:900px;}.nav-info.jsx-3612939483{position:absolute;font-size:12px;left:10%;}.links-container.jsx-3612939483,.nav-container.jsx-3612939483{display:inline-block;}.nav-right.jsx-3612939483{right:20px;position:absolute;display:inline-block;font-size:12px;}a.jsx-3612939483{color:#999;padding:10px;font-size:12px;}a.jsx-3612939483:hover{color:black;}.active.jsx-3612939483{color:black !important;}@media screen and (max-width:800px){.nav-right.jsx-3612939483{display:none;}}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXEhlYWRlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFvQk8sQUFHNEIsQUFRQyxBQUtHLEFBR1YsQUFNQSxBQUtDLEFBR1csQUFJUixXQWpCRyxBQU1MLENBS2YsQ0FPRSxJQWxDb0IsQ0FRTCxHQUtqQixFQWlCQSxDQVBpQixLQU5NLElBUlosSUFSUSxFQXVCbkIsR0FkQSxRQVFpQixJQWhCSCxXQWlCZCxDQWhCZSxhQUNHLGdCQUNsQiIsImZpbGUiOiJHOlxcZGV2XFxpcGlwXFxjb21wb25lbnRzXFxhbGhlaW1zaW5zXFxIZWFkZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGluayBmcm9tICcuL0xpbmsnXG5cbmV4cG9ydCBkZWZhdWx0ICh7IHVzZXIsIGluZm8gfSkgPT4gKFxuICA8aGVhZGVyPlxuICAgIDxkaXYgY2xhc3NOYW1lPSduYXYtY29udGFpbmVyJz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdsaW5rcy1jb250YWluZXInPlxuICAgICAgICA8TGluayByb3V0ZT0nLycgYWN0aXZlQ2xhc3NOYW1lPSdhY3RpdmUnPjxhPkhPTUU8L2E+PC9MaW5rPlxuICAgICAgICA8TGluayByb3V0ZT0nL3Rlc3QnIGFjdGl2ZUNsYXNzTmFtZT0nYWN0aXZlJz48YT5URVNUPC9hPjwvTGluaz5cbiAgICAgICAgPExpbmsgcm91dGU9Jy9yZXN1bHQnIGFjdGl2ZUNsYXNzTmFtZT0nYWN0aXZlJz48YT5SRVNVTFQ8L2E+PC9MaW5rPlxuICAgICAgICA8TGluayByb3V0ZT0nL2NvbXBhcmUnIGFjdGl2ZUNsYXNzTmFtZT0nYWN0aXZlJz48YT5DT01QQVJFPC9hPjwvTGluaz5cbiAgICAgICAgPExpbmsgcm91dGU9Jy9hYm91dCcgYWN0aXZlQ2xhc3NOYW1lPSdhY3RpdmUnPjxhPkFCT1VUPC9hPjwvTGluaz5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9J25hdi1yaWdodCc+XG4gICAgICAgIHt1c2VyXG4gICAgICAgICAgPyA8c3Bhbj5sb2dnZWQgaW4gYXMgPGI+e3VzZXJ9PC9iPjwvc3Bhbj5cbiAgICAgICAgICA6IDxhIGhyZWY9Jy9hcGkvbG9naW4nIHN0eWxlPXt7IGNvbG9yOiAnYmxhY2snIH19PkxPR0lOPC9hPn1cbiAgICAgIDwvZGl2PlxuICAgICAge2luZm8gJiYgPGRpdiBjbGFzc05hbWU9J25hdi1pbmZvJz57aW5mb308L2Rpdj59XG4gICAgPC9kaXY+XG4gICAgPHN0eWxlIGpzeD5cbiAgICAgIHtgXG4gICAgICAgIGhlYWRlciB7XG4gICAgICAgICAgZ3JpZC1hcmVhOiBoZWFkZXI7XG4gICAgICAgICAganVzdGlmeS1zZWxmOiBjZW50ZXI7XG4gICAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgICAgICAgbWFyZ2luOiBhdXRvO1xuICAgICAgICAgIHBhZGRpbmc6IDI1cHg7XG4gICAgICAgICAgbWF4LXdpZHRoOiA5MDBweDtcbiAgICAgICAgfVxuICAgICAgICAubmF2LWluZm8ge1xuICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgbGVmdDogMTAlO1xuICAgICAgICB9XG4gICAgICAgIC5saW5rcy1jb250YWluZXIsIC5uYXYtY29udGFpbmVyIHtcbiAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgIH1cbiAgICAgICAgLm5hdi1yaWdodCB7XG4gICAgICAgICAgcmlnaHQ6IDIwcHg7XG4gICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgIH1cbiAgICAgICAgYSB7XG4gICAgICAgICAgY29sb3I6ICM5OTk7XG4gICAgICAgICAgcGFkZGluZzogMTBweDtcbiAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgIH1cbiAgICAgICAgYTpob3ZlciB7XG4gICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICB9XG4gICAgICAgIC5hY3RpdmUge1xuICAgICAgICAgIGNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xuICAgICAgICB9XG4gICAgICAgIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDgwMHB4KSB7XG4gICAgICAgICAgLm5hdi1yaWdodCB7XG4gICAgICAgICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgYH1cbiAgICA8L3N0eWxlPlxuICA8L2hlYWRlcj5cbilcbiJdfQ== */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\alheimsins\\\\Header.js */")));

/***/ }),

/***/ "./components/alheimsins/InputText.js":
/*!********************************************!*\
  !*** ./components/alheimsins/InputText.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return InputText; });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function InputText(props) {
  const propTypes = {
    name: props.name,
    type: props.type || 'text',
    min: props.min,
    max: props.max,
    maxLength: props.maxLength,
    placeholder: props.placeholder,
    onChange: props.onChange,
    value: props.value || '',
    autoComplete: props.autoComplete,
    autoFocus: props.autoFocus
  };
  return __jsx("div", {
    className: "jsx-1246188565"
  }, __jsx("input", _extends({}, propTypes, {
    className: "jsx-1246188565" + " " + (propTypes && propTypes.className != null && propTypes.className || "")
  })), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
    id: "1246188565"
  }, "input.jsx-1246188565{border-width:0;background:transparent;height:18px;-moz-appearance:textfield;width:100%;padding-left:3px;}input.jsx-1246188565:focus{outline-width:0;}input.jsx-1246188565::-webkit-outer-spin-button,input.jsx-1246188565::-webkit-inner-spin-button{-webkit-appearance:none;margin:0;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXElucHV0VGV4dC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFpQlMsQUFHNEIsQUFRQyxBQUlRLGVBWEQsQ0FRekIsUUFJWSxTQUNaLEtBWmMsWUFDYywwQkFDZixXQUNNLGlCQUNuQiIsImZpbGUiOiJHOlxcZGV2XFxpcGlwXFxjb21wb25lbnRzXFxhbGhlaW1zaW5zXFxJbnB1dFRleHQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBJbnB1dFRleHQgKHByb3BzKSB7XG4gIGNvbnN0IHByb3BUeXBlcyA9IHtcbiAgICBuYW1lOiBwcm9wcy5uYW1lLFxuICAgIHR5cGU6IHByb3BzLnR5cGUgfHwgJ3RleHQnLFxuICAgIG1pbjogcHJvcHMubWluLFxuICAgIG1heDogcHJvcHMubWF4LFxuICAgIG1heExlbmd0aDogcHJvcHMubWF4TGVuZ3RoLFxuICAgIHBsYWNlaG9sZGVyOiBwcm9wcy5wbGFjZWhvbGRlcixcbiAgICBvbkNoYW5nZTogcHJvcHMub25DaGFuZ2UsXG4gICAgdmFsdWU6IHByb3BzLnZhbHVlIHx8ICcnLFxuICAgIGF1dG9Db21wbGV0ZTogcHJvcHMuYXV0b0NvbXBsZXRlLFxuICAgIGF1dG9Gb2N1czogcHJvcHMuYXV0b0ZvY3VzXG4gIH1cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGlucHV0IHsuLi5wcm9wVHlwZXN9IC8+XG4gICAgICA8c3R5bGUganN4PlxuICAgICAgICB7YFxuICAgICAgICAgIGlucHV0IHtcbiAgICAgICAgICAgIGJvcmRlci13aWR0aDogMDtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgICAgICAgICAgaGVpZ2h0OiAxOHB4O1xuICAgICAgICAgICAgLW1vei1hcHBlYXJhbmNlOiB0ZXh0ZmllbGQ7XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogM3B4O1xuICAgICAgICAgIH1cbiAgICAgICAgICBpbnB1dDpmb2N1cyB7XG4gICAgICAgICAgICBvdXRsaW5lLXdpZHRoOiAwO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpbnB1dDo6LXdlYmtpdC1vdXRlci1zcGluLWJ1dHRvbixcbiAgICAgICAgICBpbnB1dDo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbiB7XG4gICAgICAgICAgICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gICAgICAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICAgIH1cbiAgICAgICAgYH1cbiAgICAgIDwvc3R5bGU+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ== */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\alheimsins\\\\InputText.js */"));
}

/***/ }),

/***/ "./components/alheimsins/InputTextUncontrolled.js":
/*!********************************************************!*\
  !*** ./components/alheimsins/InputTextUncontrolled.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return InputText; });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function InputText(props) {
  const propTypes = {
    name: props.name,
    type: props.type || 'text',
    min: props.min,
    max: props.max,
    maxLength: props.maxLength,
    placeholder: props.placeholder,
    onChange: props.onChange,
    autoFocus: props.autoFocus
  };
  return __jsx("div", {
    className: "jsx-1246188565"
  }, __jsx("input", _extends({}, propTypes, {
    className: "jsx-1246188565" + " " + (propTypes && propTypes.className != null && propTypes.className || "")
  })), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
    id: "1246188565"
  }, "input.jsx-1246188565{border-width:0;background:transparent;height:18px;-moz-appearance:textfield;width:100%;padding-left:3px;}input.jsx-1246188565:focus{outline-width:0;}input.jsx-1246188565::-webkit-outer-spin-button,input.jsx-1246188565::-webkit-inner-spin-button{-webkit-appearance:none;margin:0;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXElucHV0VGV4dFVuY29udHJvbGxlZC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFlUyxBQUc0QixBQVFDLEFBSVEsZUFYRCxDQVF6QixRQUlZLFNBQ1osS0FaYyxZQUNjLDBCQUNmLFdBQ00saUJBQ25CIiwiZmlsZSI6Ikc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXElucHV0VGV4dFVuY29udHJvbGxlZC5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIElucHV0VGV4dCAocHJvcHMpIHtcbiAgY29uc3QgcHJvcFR5cGVzID0ge1xuICAgIG5hbWU6IHByb3BzLm5hbWUsXG4gICAgdHlwZTogcHJvcHMudHlwZSB8fCAndGV4dCcsXG4gICAgbWluOiBwcm9wcy5taW4sXG4gICAgbWF4OiBwcm9wcy5tYXgsXG4gICAgbWF4TGVuZ3RoOiBwcm9wcy5tYXhMZW5ndGgsXG4gICAgcGxhY2Vob2xkZXI6IHByb3BzLnBsYWNlaG9sZGVyLFxuICAgIG9uQ2hhbmdlOiBwcm9wcy5vbkNoYW5nZSxcbiAgICBhdXRvRm9jdXM6IHByb3BzLmF1dG9Gb2N1c1xuICB9XG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxpbnB1dCB7Li4ucHJvcFR5cGVzfSAvPlxuICAgICAgPHN0eWxlIGpzeD5cbiAgICAgICAge2BcbiAgICAgICAgICBpbnB1dCB7XG4gICAgICAgICAgICBib3JkZXItd2lkdGg6IDA7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgICAgIGhlaWdodDogMThweDtcbiAgICAgICAgICAgIC1tb3otYXBwZWFyYW5jZTogdGV4dGZpZWxkO1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDNweDtcbiAgICAgICAgICB9XG4gICAgICAgICAgaW5wdXQ6Zm9jdXMge1xuICAgICAgICAgICAgb3V0bGluZS13aWR0aDogMDtcbiAgICAgICAgICB9XG4gICAgICAgICAgaW5wdXQ6Oi13ZWJraXQtb3V0ZXItc3Bpbi1idXR0b24sXG4gICAgICAgICAgaW5wdXQ6Oi13ZWJraXQtaW5uZXItc3Bpbi1idXR0b24ge1xuICAgICAgICAgICAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xuICAgICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgICB9XG4gICAgICAgIGB9XG4gICAgICA8L3N0eWxlPlxuICAgIDwvZGl2PlxuICApXG59XG4iXX0= */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\alheimsins\\\\InputTextUncontrolled.js */"));
}

/***/ }),

/***/ "./components/alheimsins/Layout.js":
/*!*****************************************!*\
  !*** ./components/alheimsins/Layout.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Header */ "./components/alheimsins/Header.js");
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Footer */ "./components/alheimsins/Footer.js");
/* harmony import */ var _hoc_withI18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../hoc/withI18next */ "./hoc/withI18next/index.js");


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;





const Layout = ({
  user,
  children,
  t
}) => __jsx("div", {
  className: "jsx-3532321146" + " " + 'container'
}, __jsx(next_head__WEBPACK_IMPORTED_MODULE_2___default.a, null, __jsx("title", {
  className: "jsx-3532321146"
}, t('common:title')), __jsx("meta", {
  name: "viewport",
  content: "initial-scale=0.8, maximum-scale=0.8, width=device-width",
  className: "jsx-3532321146"
}), __jsx("meta", {
  property: "og:title",
  content: "Want to take a free Big Five personality test?",
  className: "jsx-3532321146"
}), __jsx("meta", {
  property: "og:description",
  content: "Take a free, open-source Big Five personality test - translated to multiple languages. Get to know yourself better from a detailed profile of your personality traits or learn to know others by comparing yourself with your partner, colleagues, friends or family.",
  className: "jsx-3532321146"
}), __jsx("meta", {
  property: "og:image",
  content: "/static/apple-icon-152x152.png",
  className: "jsx-3532321146"
}), __jsx("meta", {
  name: "theme-color",
  content: "#000000",
  className: "jsx-3532321146"
}), __jsx("meta", {
  name: "twitter:card",
  content: "summary",
  className: "jsx-3532321146"
}), __jsx("meta", {
  name: "twitter:creator",
  content: "@maccyber",
  className: "jsx-3532321146"
}), __jsx("meta", {
  name: "twitter:title",
  content: "Want to take a free Big Five personality test?",
  className: "jsx-3532321146"
}), __jsx("meta", {
  name: "twitter:description",
  content: "Get to know yourself better from a detailed profile of your personality traits or learn to know others by comparing yourself with your partner, colleagues, friends or family.",
  className: "jsx-3532321146"
}), __jsx("meta", {
  name: "twitter:image",
  content: "https://bigfive-test.com/static/apple-icon.png",
  className: "jsx-3532321146"
}), __jsx("meta", {
  name: "description",
  content: "Take a free, open-source Big Five personality test - translated to multiple languages. Get to know yourself better from a detailed profile of your personality traits or learn to know others by comparing yourself with your partner, colleagues, friends or family.",
  className: "jsx-3532321146"
}), __jsx("meta", {
  name: "keywords",
  content: "BigFive, personality traits, survey, compare",
  className: "jsx-3532321146"
}), __jsx("script", {
  type: "application/ld+json",
  dangerouslySetInnerHTML: {
    __html: '{ "@context": "http://schema.org/", "@type": "WebSite", "name": "BigFive Test", "url": "https://bigfive-test.com" }'
  },
  className: "jsx-3532321146"
}), __jsx("link", {
  rel: "icon",
  sizes: "192x192",
  href: "/static/android-icon-192x192.png",
  className: "jsx-3532321146"
}), __jsx("link", {
  rel: "apple-touch-icon",
  href: "/static/apple-icon-152x152.png",
  className: "jsx-3532321146"
}), __jsx("link", {
  rel: "shortcut icon",
  href: "/static/favicon.ico",
  className: "jsx-3532321146"
}), __jsx("link", {
  rel: "manifest",
  href: "/static/manifest.json",
  className: "jsx-3532321146"
})), __jsx(_Header__WEBPACK_IMPORTED_MODULE_3__["default"], {
  user: user
}), __jsx("div", {
  className: "jsx-3532321146" + " " + 'main'
}, children), __jsx(_Footer__WEBPACK_IMPORTED_MODULE_4__["default"], null), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "3532321146"
}, "body{background:white;color:black;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen,Ubuntu,Cantarell,'Fira Sans','Droid Sans','Helvetica Neue',sans-serif;text-align:center;margin:0;padding:0;height:100%;}::selection{background:black;color:white;}a{-webkit-text-decoration:none;text-decoration:none;}h1{font-weight:400;font-size:32px;}h2{color:#909090;font-weight:normal;}.container{display:grid;grid-template-areas: \"header header header\" \". content .\" \"footer footer footer\";grid-template-columns:1fr 2fr 1fr;grid-template-rows:auto 1fr auto;min-height:100vh;}@media screen and (max-width:800px){.container{grid-template-columns:3% 1fr 3%;}}.main{grid-area:content;width:100%;height:100%;}.main a{color:#bd10e0;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXExheW91dC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFpQ08sQUFHNEIsQUFTQSxBQUlJLEFBR0wsQUFJRixBQUlELEFBV3FCLEFBSWhCLEFBS0osYUFoQlUsQ0FQTCxBQXdCckIsRUE1QmlCLENBaEJILEFBU0EsQ0E4QkQsV0F0QzJJLEFBU3hKLEFBOEJjLEVBdkJkLENBa0JFLENBZEYsUUFvQkEsU0E1QkEsNENBZW9DLGtDQUNELGlDQUNoQixRQTVCQyxTQTZCcEIsU0E1QlcsU0FDQyxVQUNFLFlBQ2QiLCJmaWxlIjoiRzpcXGRldlxcaXBpcFxcY29tcG9uZW50c1xcYWxoZWltc2luc1xcTGF5b3V0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xuaW1wb3J0IEhlYWRlciBmcm9tICcuL0hlYWRlcidcbmltcG9ydCBGb290ZXIgZnJvbSAnLi9Gb290ZXInXG5pbXBvcnQgd2l0aEkxOG5leHQgZnJvbSAnLi4vLi4vaG9jL3dpdGhJMThuZXh0J1xuXG5jb25zdCBMYXlvdXQgPSAoeyB1c2VyLCBjaGlsZHJlbiwgdCB9KSA9PiAoXG4gIDxkaXYgY2xhc3NOYW1lPSdjb250YWluZXInPlxuICAgIDxIZWFkPlxuICAgICAgPHRpdGxlPnt0KCdjb21tb246dGl0bGUnKX08L3RpdGxlPlxuICAgICAgPG1ldGEgbmFtZT0ndmlld3BvcnQnIGNvbnRlbnQ9J2luaXRpYWwtc2NhbGU9MC44LCBtYXhpbXVtLXNjYWxlPTAuOCwgd2lkdGg9ZGV2aWNlLXdpZHRoJyAvPlxuICAgICAgPG1ldGEgcHJvcGVydHk9J29nOnRpdGxlJyBjb250ZW50PSdXYW50IHRvIHRha2UgYSBmcmVlIEJpZyBGaXZlIHBlcnNvbmFsaXR5IHRlc3Q/JyAvPlxuICAgICAgPG1ldGEgcHJvcGVydHk9J29nOmRlc2NyaXB0aW9uJyBjb250ZW50PSdUYWtlIGEgZnJlZSwgb3Blbi1zb3VyY2UgQmlnIEZpdmUgcGVyc29uYWxpdHkgdGVzdCAtIHRyYW5zbGF0ZWQgdG8gbXVsdGlwbGUgbGFuZ3VhZ2VzLiBHZXQgdG8ga25vdyB5b3Vyc2VsZiBiZXR0ZXIgZnJvbSBhIGRldGFpbGVkIHByb2ZpbGUgb2YgeW91ciBwZXJzb25hbGl0eSB0cmFpdHMgb3IgbGVhcm4gdG8ga25vdyBvdGhlcnMgYnkgY29tcGFyaW5nIHlvdXJzZWxmIHdpdGggeW91ciBwYXJ0bmVyLCBjb2xsZWFndWVzLCBmcmllbmRzIG9yIGZhbWlseS4nIC8+XG4gICAgICA8bWV0YSBwcm9wZXJ0eT0nb2c6aW1hZ2UnIGNvbnRlbnQ9Jy9zdGF0aWMvYXBwbGUtaWNvbi0xNTJ4MTUyLnBuZycgLz5cbiAgICAgIDxtZXRhIG5hbWU9J3RoZW1lLWNvbG9yJyBjb250ZW50PScjMDAwMDAwJyAvPlxuICAgICAgPG1ldGEgbmFtZT0ndHdpdHRlcjpjYXJkJyBjb250ZW50PSdzdW1tYXJ5JyAvPlxuICAgICAgPG1ldGEgbmFtZT0ndHdpdHRlcjpjcmVhdG9yJyBjb250ZW50PSdAbWFjY3liZXInIC8+XG4gICAgICA8bWV0YSBuYW1lPSd0d2l0dGVyOnRpdGxlJyBjb250ZW50PSdXYW50IHRvIHRha2UgYSBmcmVlIEJpZyBGaXZlIHBlcnNvbmFsaXR5IHRlc3Q/JyAvPlxuICAgICAgPG1ldGEgbmFtZT0ndHdpdHRlcjpkZXNjcmlwdGlvbicgY29udGVudD0nR2V0IHRvIGtub3cgeW91cnNlbGYgYmV0dGVyIGZyb20gYSBkZXRhaWxlZCBwcm9maWxlIG9mIHlvdXIgcGVyc29uYWxpdHkgdHJhaXRzIG9yIGxlYXJuIHRvIGtub3cgb3RoZXJzIGJ5IGNvbXBhcmluZyB5b3Vyc2VsZiB3aXRoIHlvdXIgcGFydG5lciwgY29sbGVhZ3VlcywgZnJpZW5kcyBvciBmYW1pbHkuJyAvPlxuICAgICAgPG1ldGEgbmFtZT0ndHdpdHRlcjppbWFnZScgY29udGVudD0naHR0cHM6Ly9iaWdmaXZlLXRlc3QuY29tL3N0YXRpYy9hcHBsZS1pY29uLnBuZycgLz5cbiAgICAgIDxtZXRhIG5hbWU9J2Rlc2NyaXB0aW9uJyBjb250ZW50PSdUYWtlIGEgZnJlZSwgb3Blbi1zb3VyY2UgQmlnIEZpdmUgcGVyc29uYWxpdHkgdGVzdCAtIHRyYW5zbGF0ZWQgdG8gbXVsdGlwbGUgbGFuZ3VhZ2VzLiBHZXQgdG8ga25vdyB5b3Vyc2VsZiBiZXR0ZXIgZnJvbSBhIGRldGFpbGVkIHByb2ZpbGUgb2YgeW91ciBwZXJzb25hbGl0eSB0cmFpdHMgb3IgbGVhcm4gdG8ga25vdyBvdGhlcnMgYnkgY29tcGFyaW5nIHlvdXJzZWxmIHdpdGggeW91ciBwYXJ0bmVyLCBjb2xsZWFndWVzLCBmcmllbmRzIG9yIGZhbWlseS4nIC8+XG4gICAgICA8bWV0YSBuYW1lPSdrZXl3b3JkcycgY29udGVudD0nQmlnRml2ZSwgcGVyc29uYWxpdHkgdHJhaXRzLCBzdXJ2ZXksIGNvbXBhcmUnIC8+XG4gICAgICA8c2NyaXB0IHR5cGU9J2FwcGxpY2F0aW9uL2xkK2pzb24nIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7IF9faHRtbDogJ3sgXCJAY29udGV4dFwiOiBcImh0dHA6Ly9zY2hlbWEub3JnL1wiLCBcIkB0eXBlXCI6IFwiV2ViU2l0ZVwiLCBcIm5hbWVcIjogXCJCaWdGaXZlIFRlc3RcIiwgXCJ1cmxcIjogXCJodHRwczovL2JpZ2ZpdmUtdGVzdC5jb21cIiB9JyB9fSAvPlxuICAgICAgPGxpbmsgcmVsPSdpY29uJyBzaXplcz0nMTkyeDE5MicgaHJlZj0nL3N0YXRpYy9hbmRyb2lkLWljb24tMTkyeDE5Mi5wbmcnIC8+XG4gICAgICA8bGluayByZWw9J2FwcGxlLXRvdWNoLWljb24nIGhyZWY9Jy9zdGF0aWMvYXBwbGUtaWNvbi0xNTJ4MTUyLnBuZycgLz5cbiAgICAgIDxsaW5rIHJlbD0nc2hvcnRjdXQgaWNvbicgaHJlZj0nL3N0YXRpYy9mYXZpY29uLmljbycgLz5cbiAgICAgIDxsaW5rIHJlbD0nbWFuaWZlc3QnIGhyZWY9Jy9zdGF0aWMvbWFuaWZlc3QuanNvbicgLz5cbiAgICA8L0hlYWQ+XG4gICAgPEhlYWRlciB1c2VyPXt1c2VyfSAvPlxuICAgIDxkaXYgY2xhc3NOYW1lPSdtYWluJz5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L2Rpdj5cbiAgICA8Rm9vdGVyIC8+XG4gICAgPHN0eWxlIGpzeCBnbG9iYWw+XG4gICAgICB7YFxuICAgICAgICBib2R5IHtcbiAgICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgICAgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgJ1NlZ29lIFVJJywgUm9ib3RvLCBPeHlnZW4sIFVidW50dSwgQ2FudGFyZWxsLCAnRmlyYSBTYW5zJywgJ0Ryb2lkIFNhbnMnLCAnSGVsdmV0aWNhIE5ldWUnLCBzYW5zLXNlcmlmO1xuICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgIH1cbiAgICAgICAgOjpzZWxlY3Rpb24ge1xuICAgICAgICAgIGJhY2tncm91bmQ6IGJsYWNrO1xuICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgfVxuICAgICAgICBhIHtcbiAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gICAgICAgIH1cbiAgICAgICAgaDEge1xuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgICAgICAgZm9udC1zaXplOiAzMnB4O1xuICAgICAgICB9XG4gICAgICAgIGgyIHtcbiAgICAgICAgICBjb2xvcjogIzkwOTA5MDtcbiAgICAgICAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgICAgICB9XG4gICAgICAgIC5jb250YWluZXIge1xuICAgICAgICAgIGRpc3BsYXk6IGdyaWQ7XG4gICAgICAgICAgZ3JpZC10ZW1wbGF0ZS1hcmVhczpcbiAgICAgICAgICAgIFwiaGVhZGVyIGhlYWRlciBoZWFkZXJcIlxuICAgICAgICAgICAgXCIuIGNvbnRlbnQgLlwiXG4gICAgICAgICAgICBcImZvb3RlciBmb290ZXIgZm9vdGVyXCI7XG4gICAgICAgICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgMmZyIDFmcjtcbiAgICAgICAgICBncmlkLXRlbXBsYXRlLXJvd3M6IGF1dG8gMWZyIGF1dG87XG4gICAgICAgICAgbWluLWhlaWdodDogMTAwdmg7XG4gICAgICAgIH1cbiAgICAgICAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogODAwcHgpIHtcbiAgICAgICAgICAuY29udGFpbmVyIHtcbiAgICAgICAgICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogMyUgMWZyIDMlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAubWFpbiB7XG4gICAgICAgICAgZ3JpZC1hcmVhOiBjb250ZW50O1xuICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgfVxuICAgICAgICAubWFpbiBhIHtcbiAgICAgICAgICBjb2xvcjogI2JkMTBlMDtcbiAgICAgICAgfVxuICAgICAgYH1cbiAgICA8L3N0eWxlPlxuICA8L2Rpdj5cbilcblxuZXhwb3J0IGRlZmF1bHQgd2l0aEkxOG5leHQoWydjb21tb24nXSkoTGF5b3V0KVxuIl19 */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\alheimsins\\\\Layout.js */"));

/* harmony default export */ __webpack_exports__["default"] = (Object(_hoc_withI18next__WEBPACK_IMPORTED_MODULE_5__["default"])(['common'])(Layout));

/***/ }),

/***/ "./components/alheimsins/Link.js":
/*!***************************************!*\
  !*** ./components/alheimsins/Link.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../routes */ "./routes.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement;

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const ActiveLink = (_ref) => {
  let {
    router,
    children
  } = _ref,
      props = _objectWithoutProperties(_ref, ["router", "children"]);

  const child = react__WEBPACK_IMPORTED_MODULE_2__["Children"].only(children);
  let className = child.props.className || null;
  const route = props.route.toLowerCase().substring(1);
  const pathname = router.pathname.toLowerCase();

  if (router.pathname === props.route || route.length > 1 && pathname.includes(route) && props.activeClassName) {
    className = `${className !== null ? className : ''} ${props.activeClassName}`.trim();
  }

  delete props.activeClassName;
  return __jsx(_routes__WEBPACK_IMPORTED_MODULE_1__["Link"], props, react__WEBPACK_IMPORTED_MODULE_2___default.a.cloneElement(child, {
    className
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(next_router__WEBPACK_IMPORTED_MODULE_0__["withRouter"])(ActiveLink));

/***/ }),

/***/ "./components/alheimsins/Loading.js":
/*!******************************************!*\
  !*** ./components/alheimsins/Loading.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;
/* harmony default export */ __webpack_exports__["default"] = (() => __jsx("div", {
  className: "jsx-1431270607" + " " + 'loading'
}, __jsx("img", {
  src: "/static/spinner.gif",
  style: {
    width: 30
  },
  className: "jsx-1431270607"
}), __jsx("big", {
  style: {
    marginLeft: '8px',
    verticalAlign: 'text-bottom'
  },
  className: "jsx-1431270607"
}, "LOADING ..."), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "1431270607"
}, ".loading.jsx-1431270607{text-align:center;line-height:34px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXExvYWRpbmcuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBS08sQUFHMkIsa0JBQ0QsaUJBQ25CIiwiZmlsZSI6Ikc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXExvYWRpbmcuanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCAoKSA9PiAoXG4gIDxkaXYgY2xhc3NOYW1lPSdsb2FkaW5nJz5cbiAgICA8aW1nIHNyYz0nL3N0YXRpYy9zcGlubmVyLmdpZicgc3R5bGU9e3sgd2lkdGg6IDMwIH19IC8+XG4gICAgPGJpZyBzdHlsZT17eyBtYXJnaW5MZWZ0OiAnOHB4JywgdmVydGljYWxBbGlnbjogJ3RleHQtYm90dG9tJyB9fT5MT0FESU5HIC4uLjwvYmlnPlxuICAgIDxzdHlsZSBqc3g+XG4gICAgICB7YFxuICAgICAgLmxvYWRpbmcge1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAzNHB4O1xuICAgICAgfVxuICAgIGB9XG4gICAgPC9zdHlsZT5cbiAgPC9kaXY+XG4pXG4iXX0= */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\alheimsins\\\\Loading.js */")));

/***/ }),

/***/ "./components/alheimsins/Logo.js":
/*!***************************************!*\
  !*** ./components/alheimsins/Logo.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;
/* harmony default export */ __webpack_exports__["default"] = (({
  color
}) => __jsx("div", {
  className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1971824170", [color || 'black']]]) + " " + 'logo-container'
}, __jsx("svg", {
  viewBox: "0 0 310 200",
  className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1971824170", [color || 'black']]]) + " " + 'logo'
}, __jsx("path", {
  id: "svg_3",
  d: "m189.652989,153.487896l-7.0313,12.0937l-79.5937,-45.8437l0,91.8281l-14.0625,0l0,-91.8281l-79.5938,45.8437l-7.0312,-12.0937l79.5938,-45.9844l-79.5938,-45.9844l7.0312,-12.0937l79.5938,45.8437l0,-91.8281l14.0625,0l0,91.8281l79.5937,-45.8437l7.0313,12.0937l-79.5937,45.9844l79.5937,45.9844z",
  className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1971824170", [color || 'black']]])
})), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "1971824170",
  dynamic: [color || 'black']
}, `.logo-container.__jsx-style-dynamic-selector{display:inline-block;vertical-align:middle;}.logo.__jsx-style-dynamic-selector{width:25px;fill:${color || 'black'};}
/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXExvZ28uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBTU8sQUFHZ0MsQUFJVixXQUN1QixVQUpaLHNCQUN4QixFQUlBIiwiZmlsZSI6Ikc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXExvZ28uanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCAoeyBjb2xvciB9KSA9PiAoXG4gIDxkaXYgY2xhc3NOYW1lPSdsb2dvLWNvbnRhaW5lcic+XG4gICAgPHN2ZyBjbGFzc05hbWU9J2xvZ28nIHZpZXdCb3g9JzAgMCAzMTAgMjAwJz5cbiAgICAgIDxwYXRoIGlkPSdzdmdfMycgZD0nbTE4OS42NTI5ODksMTUzLjQ4Nzg5NmwtNy4wMzEzLDEyLjA5MzdsLTc5LjU5MzcsLTQ1Ljg0MzdsMCw5MS44MjgxbC0xNC4wNjI1LDBsMCwtOTEuODI4MWwtNzkuNTkzOCw0NS44NDM3bC03LjAzMTIsLTEyLjA5MzdsNzkuNTkzOCwtNDUuOTg0NGwtNzkuNTkzOCwtNDUuOTg0NGw3LjAzMTIsLTEyLjA5MzdsNzkuNTkzOCw0NS44NDM3bDAsLTkxLjgyODFsMTQuMDYyNSwwbDAsOTEuODI4MWw3OS41OTM3LC00NS44NDM3bDcuMDMxMywxMi4wOTM3bC03OS41OTM3LDQ1Ljk4NDRsNzkuNTkzNyw0NS45ODQ0eicgLz5cbiAgICA8L3N2Zz5cbiAgICA8c3R5bGUganN4PlxuICAgICAge2BcbiAgICAgICAgLmxvZ28tY29udGFpbmVyIHtcbiAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICAgICAgfVxuICAgICAgICAubG9nbyB7XG4gICAgICAgICAgd2lkdGg6IDI1cHg7XG4gICAgICAgICAgZmlsbDogJHtjb2xvciB8fCAnYmxhY2snfTtcbiAgICAgICAgfVxuICAgIGB9XG4gICAgPC9zdHlsZT5cbiAgPC9kaXY+XG4pXG4iXX0= */
/*@ sourceURL=G:\\dev\\ipip\\components\\alheimsins\\Logo.js */`)));

/***/ }),

/***/ "./components/alheimsins/ProgressBar.js":
/*!**********************************************!*\
  !*** ./components/alheimsins/ProgressBar.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;
/* harmony default export */ __webpack_exports__["default"] = (({
  progress
}) => __jsx("div", {
  className: "progress",
  style: {
    color: progress > 52 ? '#fff' : '#828282'
  }
}, __jsx("span", {
  className: "percent"
}, progress, "%"), __jsx("div", {
  style: {
    width: progress + '%'
  },
  className: "bar"
}), __jsx("style", null, `
        .progress {
          background-color: #f1f1f1;
          height: 100%;
          margin-top: 3%;
          border: 1px;
          border-radius: 5px;
          width: 100%;
        }
        .percent {
          position: absolute;
          left: 50%;
        }
        .bar {
          height: 20px;
          background-color: #000;
          transition: width 2s;
          border: 1px;
          border-radius: 5px;
        }
      `)));

/***/ }),

/***/ "./components/alheimsins/Radio.js":
/*!****************************************!*\
  !*** ./components/alheimsins/Radio.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Radio; });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/md */ "react-icons/md");
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_3__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;



class Radio extends react__WEBPACK_IMPORTED_MODULE_1__["Component"] {
  render() {
    const {
      name,
      checked,
      onChange
    } = this.context.radioGroup;
    const choosen = checked === this.props.value;
    return [__jsx("label", {
      key: this.props.value,
      className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["170048557", [this.props.checkedColor || 'black', this.props.uncheckedColor || 'black']]])
    }, __jsx("input", {
      type: "radio",
      name: name,
      value: this.props.value,
      checked: choosen,
      onChange: onChange,
      className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["170048557", [this.props.checkedColor || 'black', this.props.uncheckedColor || 'black']]])
    }), __jsx("span", {
      style: this.props.style,
      className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["170048557", [this.props.checkedColor || 'black', this.props.uncheckedColor || 'black']]]) + " " + 'radios'
    }, choosen ? __jsx("span", {
      role: "radio",
      className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["170048557", [this.props.checkedColor || 'black', this.props.uncheckedColor || 'black']]]) + " " + ((this.props.color ? `color${this.props.color}` : 'checked') || "")
    }, __jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_3__["MdRadioButtonChecked"], null)) : __jsx("span", {
      role: "radio",
      className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["170048557", [this.props.checkedColor || 'black', this.props.uncheckedColor || 'black']]]) + " " + 'unchecked'
    }, __jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_3__["MdRadioButtonUnchecked"], null)), "\xA0", this.props.text), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
      id: "170048557",
      dynamic: [this.props.checkedColor || 'black', this.props.uncheckedColor || 'black']
    }, `input.__jsx-style-dynamic-selector{display:none;}.radios.__jsx-style-dynamic-selector{cursor:pointer;margin-right:5px;}.checked.__jsx-style-dynamic-selector{color:${this.props.checkedColor || 'black'};}.color5.__jsx-style-dynamic-selector{color:#FF0080;}.color4.__jsx-style-dynamic-selector{color:#FF47A3;}.color3.__jsx-style-dynamic-selector{color:#FF70B8;}.color2.__jsx-style-dynamic-selector{color:#FF85C2;}.color1.__jsx-style-dynamic-selector{color:#FFADD6;}.unchecked.__jsx-style-dynamic-selector{fill:${this.props.uncheckedColor || 'black'};}@media screen and (max-width:800px){.radios.__jsx-style-dynamic-selector{margin-top:4px;font-size:18px;}}
/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXFJhZGlvLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQW1CVyxBQUc0QixBQUdFLEFBS2xCLEFBQ3dCLEFBQ0EsQUFDQSxBQUNBLEFBQ0EsQUFHeEIsQUFHb0IsYUFsQm5CLENBUXdCLEFBQ0EsQUFDQSxBQUNBLEFBQ0EsQ0FUTCxBQWdCQSxlQUNqQixFQWhCRixFQVdBLENBUkEiLCJmaWxlIjoiRzpcXGRldlxcaXBpcFxcY29tcG9uZW50c1xcYWxoZWltc2luc1xcUmFkaW8uanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcbmltcG9ydCB7IE1kUmFkaW9CdXR0b25DaGVja2VkLCBNZFJhZGlvQnV0dG9uVW5jaGVja2VkIH0gZnJvbSAncmVhY3QtaWNvbnMvbWQnXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFJhZGlvIGV4dGVuZHMgQ29tcG9uZW50IHtcbiAgcmVuZGVyICgpIHtcbiAgICBjb25zdCB7IG5hbWUsIGNoZWNrZWQsIG9uQ2hhbmdlIH0gPSB0aGlzLmNvbnRleHQucmFkaW9Hcm91cFxuICAgIGNvbnN0IGNob29zZW4gPSBjaGVja2VkID09PSB0aGlzLnByb3BzLnZhbHVlXG4gICAgcmV0dXJuIFtcbiAgICAgIDxsYWJlbCBrZXk9e3RoaXMucHJvcHMudmFsdWV9PlxuICAgICAgICA8aW5wdXQgdHlwZT0ncmFkaW8nIG5hbWU9e25hbWV9IHZhbHVlPXt0aGlzLnByb3BzLnZhbHVlfSBjaGVja2VkPXtjaG9vc2VufSBvbkNoYW5nZT17b25DaGFuZ2V9IC8+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT0ncmFkaW9zJyBzdHlsZT17dGhpcy5wcm9wcy5zdHlsZX0+XG4gICAgICAgICAge2Nob29zZW5cbiAgICAgICAgICAgID8gPHNwYW4gcm9sZT0ncmFkaW8nIGNsYXNzTmFtZT17dGhpcy5wcm9wcy5jb2xvciA/IGBjb2xvciR7dGhpcy5wcm9wcy5jb2xvcn1gIDogJ2NoZWNrZWQnfT48TWRSYWRpb0J1dHRvbkNoZWNrZWQgLz48L3NwYW4+XG4gICAgICAgICAgICA6IDxzcGFuIHJvbGU9J3JhZGlvJyBjbGFzc05hbWU9J3VuY2hlY2tlZCc+PE1kUmFkaW9CdXR0b25VbmNoZWNrZWQgLz48L3NwYW4+fVxuICAgICAgICAgICAgJm5ic3A7XG4gICAgICAgICAge3RoaXMucHJvcHMudGV4dH1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgICA8c3R5bGUganN4PlxuICAgICAgICAgIHtgXG4gICAgICAgICAgICBpbnB1dCB7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAucmFkaW9zIHtcbiAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5jaGVja2VkIHtcbiAgICAgICAgICAgICAgY29sb3I6ICR7dGhpcy5wcm9wcy5jaGVja2VkQ29sb3IgfHwgJ2JsYWNrJ31cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5jb2xvcjUgeyBjb2xvcjogI0ZGMDA4MCB9XG4gICAgICAgICAgICAuY29sb3I0IHsgY29sb3I6ICNGRjQ3QTMgfVxuICAgICAgICAgICAgLmNvbG9yMyB7IGNvbG9yOiAjRkY3MEI4IH1cbiAgICAgICAgICAgIC5jb2xvcjIgeyBjb2xvcjogI0ZGODVDMiB9XG4gICAgICAgICAgICAuY29sb3IxIHsgY29sb3I6ICNGRkFERDYgfVxuICAgICAgICAgICAgLnVuY2hlY2tlZCB7XG4gICAgICAgICAgICAgIGZpbGw6ICR7dGhpcy5wcm9wcy51bmNoZWNrZWRDb2xvciB8fCAnYmxhY2snfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogODAwcHgpIHtcbiAgICAgICAgICAgICAgLnJhZGlvcyB7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogNHB4O1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIGB9XG4gICAgICAgIDwvc3R5bGU+XG4gICAgICA8L2xhYmVsPlxuICAgIF1cbiAgfVxufVxuXG5SYWRpby5jb250ZXh0VHlwZXMgPSB7XG4gIHJhZGlvR3JvdXA6IFByb3BUeXBlcy5vYmplY3Rcbn1cbiJdfQ== */
/*@ sourceURL=G:\\dev\\ipip\\components\\alheimsins\\Radio.js */`))];
  }

}
Radio.contextTypes = {
  radioGroup: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.object
};

/***/ }),

/***/ "./components/alheimsins/RadioGroup.js":
/*!*********************************************!*\
  !*** ./components/alheimsins/RadioGroup.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RadioGroup; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;


class RadioGroup extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  getChildContext() {
    const {
      name,
      checked,
      onChange
    } = this.props;
    return {
      radioGroup: {
        name,
        checked,
        onChange
      }
    };
  }

  render() {
    return __jsx("div", null, this.props.children);
  }

}
RadioGroup.childContextTypes = {
  radioGroup: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
};

/***/ }),

/***/ "./components/alheimsins/Select.js":
/*!*****************************************!*\
  !*** ./components/alheimsins/Select.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Select; });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }


function Select(props) {
  const propTypes = {
    name: props.name,
    id: props.name,
    defaultValue: props.defaultValue
  };
  return __jsx("div", {
    className: "jsx-585337845"
  }, __jsx("select", _extends({
    name: "country",
    "aria-label": props.name
  }, propTypes, {
    className: "jsx-585337845" + " " + (propTypes && propTypes.className != null && propTypes.className || "")
  }), props.options.map(option => __jsx("option", {
    key: option.code,
    value: option.code,
    className: "jsx-585337845"
  }, option.name))), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
    id: "585337845"
  }, "select.jsx-585337845{border-width:0;background:none;outline-width:0;width:100%;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXFNlbGVjdC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFpQlMsQUFHNEIsZUFDQyxnQkFDQSxnQkFDTCxXQUNiIiwiZmlsZSI6Ikc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXFNlbGVjdC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2VsZWN0IChwcm9wcykge1xuICBjb25zdCBwcm9wVHlwZXMgPSB7XG4gICAgbmFtZTogcHJvcHMubmFtZSxcbiAgICBpZDogcHJvcHMubmFtZSxcbiAgICBkZWZhdWx0VmFsdWU6IHByb3BzLmRlZmF1bHRWYWx1ZVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPHNlbGVjdCBuYW1lPSdjb3VudHJ5JyBhcmlhLWxhYmVsPXtwcm9wcy5uYW1lfSB7Li4ucHJvcFR5cGVzfT5cbiAgICAgICAge3Byb3BzLm9wdGlvbnMubWFwKG9wdGlvbiA9PlxuICAgICAgICAgIDxvcHRpb24ga2V5PXtvcHRpb24uY29kZX0gdmFsdWU9e29wdGlvbi5jb2RlfT57b3B0aW9uLm5hbWV9PC9vcHRpb24+XG4gICAgICAgICl9XG4gICAgICA8L3NlbGVjdD5cbiAgICAgIDxzdHlsZSBqc3g+XG4gICAgICAgIHtgXG4gICAgICAgICAgc2VsZWN0IHtcbiAgICAgICAgICAgIGJvcmRlci13aWR0aDogMDtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IG5vbmU7XG4gICAgICAgICAgICBvdXRsaW5lLXdpZHRoOiAwO1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgfVxuICAgICAgICBgfVxuICAgICAgPC9zdHlsZT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl19 */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\alheimsins\\\\Select.js */"));
}

/***/ }),

/***/ "./components/alheimsins/ShortcutH1.js":
/*!*********************************************!*\
  !*** ./components/alheimsins/ShortcutH1.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../routes */ "./routes.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/fa */ "react-icons/fa");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;


/* harmony default export */ __webpack_exports__["default"] = (({
  name
}) => __jsx("h1", {
  className: "jsx-4034187440"
}, __jsx(_routes__WEBPACK_IMPORTED_MODULE_2__["Link"], {
  route: '#' + name.toLowerCase()
}, __jsx("a", {
  id: name.toLowerCase(),
  className: "jsx-4034187440"
}, name, __jsx("i", {
  className: "jsx-4034187440" + " " + 'shortcut'
}, " ", __jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__["FaLink"], {
  size: 10
})))), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "4034187440"
}, "h1.jsx-4034187440 a.jsx-4034187440{color:unset;text-transform:capitalize;}h1.jsx-4034187440 a.jsx-4034187440:hover{color:black;}.shortcut.jsx-4034187440{visibility:hidden;color:#909090;}h1.jsx-4034187440 a.jsx-4034187440:hover .shortcut.jsx-4034187440{visibility:visible;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXFNob3J0Y3V0SDEuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBU08sQUFHdUIsQUFJQSxBQUdNLEFBSUMsWUFWTyxBQUk1QixNQUdnQixDQUloQixhQUhBLE1BUEEiLCJmaWxlIjoiRzpcXGRldlxcaXBpcFxcY29tcG9uZW50c1xcYWxoZWltc2luc1xcU2hvcnRjdXRIMS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICcuLi8uLi9yb3V0ZXMnXG5pbXBvcnQgeyBGYUxpbmsgfSBmcm9tICdyZWFjdC1pY29ucy9mYSdcblxuZXhwb3J0IGRlZmF1bHQgKHsgbmFtZSB9KSA9PiAoXG4gIDxoMT5cbiAgICA8TGluayByb3V0ZT17JyMnICsgbmFtZS50b0xvd2VyQ2FzZSgpfT5cbiAgICAgIDxhIGlkPXtuYW1lLnRvTG93ZXJDYXNlKCl9PntuYW1lfTxpIGNsYXNzTmFtZT0nc2hvcnRjdXQnPiA8RmFMaW5rIHNpemU9ezEwfSAvPjwvaT48L2E+XG4gICAgPC9MaW5rPlxuICAgIDxzdHlsZSBqc3g+XG4gICAgICB7YFxuICAgICAgICBoMSBhIHtcbiAgICAgICAgICBjb2xvcjogdW5zZXQ7XG4gICAgICAgICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gICAgICAgIH1cbiAgICAgICAgaDEgYTpob3ZlciB7XG4gICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICB9XG4gICAgICAgIC5zaG9ydGN1dCB7XG4gICAgICAgICAgdmlzaWJpbGl0eTogaGlkZGVuO1xuICAgICAgICAgIGNvbG9yOiAjOTA5MDkwO1xuICAgICAgICB9XG4gICAgICAgIGgxIGE6aG92ZXIgLnNob3J0Y3V0IHtcbiAgICAgICAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICAgICAgICB9XG4gICAgICBgfVxuICAgIDwvc3R5bGU+XG4gIDwvaDE+XG4pXG4iXX0= */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\alheimsins\\\\ShortcutH1.js */")));

/***/ }),

/***/ "./components/alheimsins/ShortcutH2.js":
/*!*********************************************!*\
  !*** ./components/alheimsins/ShortcutH2.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../routes */ "./routes.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/fa */ "react-icons/fa");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;


/* harmony default export */ __webpack_exports__["default"] = (({
  name
}) => __jsx("h2", {
  className: "jsx-3506994838"
}, __jsx(_routes__WEBPACK_IMPORTED_MODULE_2__["Link"], {
  route: '#' + name.toLowerCase()
}, __jsx("a", {
  id: name.toLowerCase(),
  className: "jsx-3506994838"
}, name, __jsx("i", {
  className: "jsx-3506994838" + " " + 'shortcut'
}, " ", __jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__["FaLink"], {
  size: 10
})))), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "3506994838"
}, "h2.jsx-3506994838 a.jsx-3506994838{color:unset;text-transform:capitalize;}h2.jsx-3506994838 a.jsx-3506994838:hover{color:black;}.shortcut.jsx-3506994838{visibility:hidden;color:#909090;}h2.jsx-3506994838 a.jsx-3506994838:hover .shortcut.jsx-3506994838{visibility:visible;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXGFsaGVpbXNpbnNcXFNob3J0Y3V0SDIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBU08sQUFHdUIsQUFJQSxBQUdNLEFBSUMsWUFWTyxBQUk1QixNQUdnQixDQUloQixhQUhBLE1BUEEiLCJmaWxlIjoiRzpcXGRldlxcaXBpcFxcY29tcG9uZW50c1xcYWxoZWltc2luc1xcU2hvcnRjdXRIMi5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICcuLi8uLi9yb3V0ZXMnXG5pbXBvcnQgeyBGYUxpbmsgfSBmcm9tICdyZWFjdC1pY29ucy9mYSdcblxuZXhwb3J0IGRlZmF1bHQgKHsgbmFtZSB9KSA9PiAoXG4gIDxoMj5cbiAgICA8TGluayByb3V0ZT17JyMnICsgbmFtZS50b0xvd2VyQ2FzZSgpfT5cbiAgICAgIDxhIGlkPXtuYW1lLnRvTG93ZXJDYXNlKCl9PntuYW1lfTxpIGNsYXNzTmFtZT0nc2hvcnRjdXQnPiA8RmFMaW5rIHNpemU9ezEwfSAvPjwvaT48L2E+XG4gICAgPC9MaW5rPlxuICAgIDxzdHlsZSBqc3g+XG4gICAgICB7YFxuICAgICAgICBoMiBhIHtcbiAgICAgICAgICBjb2xvcjogdW5zZXQ7XG4gICAgICAgICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gICAgICAgIH1cbiAgICAgICAgaDIgYTpob3ZlciB7XG4gICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICB9XG4gICAgICAgIC5zaG9ydGN1dCB7XG4gICAgICAgICAgdmlzaWJpbGl0eTogaGlkZGVuO1xuICAgICAgICAgIGNvbG9yOiAjOTA5MDkwO1xuICAgICAgICB9XG4gICAgICAgIGgyIGE6aG92ZXIgLnNob3J0Y3V0IHtcbiAgICAgICAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICAgICAgICB9XG4gICAgICBgfVxuICAgIDwvc3R5bGU+XG4gIDwvaDI+XG4pXG4iXX0= */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\alheimsins\\\\ShortcutH2.js */")));

/***/ }),

/***/ "./components/alheimsins/Timer.js":
/*!****************************************!*\
  !*** ./components/alheimsins/Timer.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;


const secToMin = seconds => {
  const minuteDivisor = seconds % (60 * 60);
  const minutes = Math.floor(minuteDivisor / 60);
  const secondDivisor = minuteDivisor % 60;
  let remSecs = Math.ceil(secondDivisor);

  switch (seconds) {
    case seconds < 10:
      return `0:0${seconds}`;

    case seconds < 60:
      return `0:${seconds}`;

    default:
      if (remSecs < 10 && remSecs > 0) remSecs = `0${remSecs}`;
      if (remSecs === 0) remSecs = `${remSecs}0`;
      return `${minutes}:${remSecs}`;
  }
};

/* harmony default export */ __webpack_exports__["default"] = (class extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      elapsed: 0
    };
    this.tick = this.tick.bind(this);
  }

  componentDidMount() {
    this.timer = setInterval(this.tick, 1000);
  }

  componentWillUnmount() {
    clearInterval(this.timer);
  }

  tick() {
    this.setState({
      elapsed: new Date() - this.props.start
    });
  }

  render() {
    const seconds = Math.round(this.state.elapsed / 1000);
    return __jsx("div", null, secToMin(seconds));
  }

});

/***/ }),

/***/ "./components/alheimsins/index.js":
/*!****************************************!*\
  !*** ./components/alheimsins/index.js ***!
  \****************************************/
/*! exports provided: Layout, Button, RadioGroup, Radio, ProgressBar, Timer, InputText, InputTextUncontrolled, Field, Loading, Code, Select, ShortcutH2, ShortcutH1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Layout */ "./components/alheimsins/Layout.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Layout", function() { return _Layout__WEBPACK_IMPORTED_MODULE_0__["default"]; });

/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ "./components/alheimsins/Button.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Button", function() { return _Button__WEBPACK_IMPORTED_MODULE_1__["default"]; });

/* harmony import */ var _RadioGroup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./RadioGroup */ "./components/alheimsins/RadioGroup.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RadioGroup", function() { return _RadioGroup__WEBPACK_IMPORTED_MODULE_2__["default"]; });

/* harmony import */ var _Radio__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Radio */ "./components/alheimsins/Radio.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Radio", function() { return _Radio__WEBPACK_IMPORTED_MODULE_3__["default"]; });

/* harmony import */ var _ProgressBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ProgressBar */ "./components/alheimsins/ProgressBar.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ProgressBar", function() { return _ProgressBar__WEBPACK_IMPORTED_MODULE_4__["default"]; });

/* harmony import */ var _Timer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Timer */ "./components/alheimsins/Timer.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Timer", function() { return _Timer__WEBPACK_IMPORTED_MODULE_5__["default"]; });

/* harmony import */ var _InputText__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./InputText */ "./components/alheimsins/InputText.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputText", function() { return _InputText__WEBPACK_IMPORTED_MODULE_6__["default"]; });

/* harmony import */ var _InputTextUncontrolled__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./InputTextUncontrolled */ "./components/alheimsins/InputTextUncontrolled.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputTextUncontrolled", function() { return _InputTextUncontrolled__WEBPACK_IMPORTED_MODULE_7__["default"]; });

/* harmony import */ var _Field__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Field */ "./components/alheimsins/Field.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Field", function() { return _Field__WEBPACK_IMPORTED_MODULE_8__["default"]; });

/* harmony import */ var _Loading__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Loading */ "./components/alheimsins/Loading.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Loading", function() { return _Loading__WEBPACK_IMPORTED_MODULE_9__["default"]; });

/* harmony import */ var _Code__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./Code */ "./components/alheimsins/Code.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Code", function() { return _Code__WEBPACK_IMPORTED_MODULE_10__["default"]; });

/* harmony import */ var _Select__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Select */ "./components/alheimsins/Select.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Select", function() { return _Select__WEBPACK_IMPORTED_MODULE_11__["default"]; });

/* harmony import */ var _ShortcutH2__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./ShortcutH2 */ "./components/alheimsins/ShortcutH2.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ShortcutH2", function() { return _ShortcutH2__WEBPACK_IMPORTED_MODULE_12__["default"]; });

/* harmony import */ var _ShortcutH1__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ShortcutH1 */ "./components/alheimsins/ShortcutH1.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ShortcutH1", function() { return _ShortcutH1__WEBPACK_IMPORTED_MODULE_13__["default"]; });
















/***/ }),

/***/ "./hoc/withI18next/index.js":
/*!**********************************!*\
  !*** ./hoc/withI18next/index.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-i18next */ "react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../i18n */ "./i18n.js");
/* harmony import */ var _i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_i18n__WEBPACK_IMPORTED_MODULE_2__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




/* harmony default export */ __webpack_exports__["default"] = ((namespaces = ['translation']) => ComposedComponent => {
  const Extended = (_ref) => {
    let {
      i18n
    } = _ref,
        rest = _objectWithoutProperties(_ref, ["i18n"]);

    // on client we only get a serialized i18n instance
    // as we do not have to use the one on req we just use the one instance
    const finalI18n = i18n || _i18n__WEBPACK_IMPORTED_MODULE_2___default.a;
    return __jsx(react_i18next__WEBPACK_IMPORTED_MODULE_1__["NamespacesConsumer"], _extends({
      i18n: finalI18n,
      ns: namespaces
    }, rest, {
      wait: false
    }), t => __jsx(ComposedComponent, _extends({
      t: t
    }, rest)));
  };

  Extended.getInitialProps = async ctx => {
    const composedInitialProps = ComposedComponent.getInitialProps ? await ComposedComponent.getInitialProps(ctx) : {};
    const i18nInitialProps = _i18n__WEBPACK_IMPORTED_MODULE_2___default.a.getInitialProps(ctx.req, namespaces);
    return _objectSpread({}, composedInitialProps, {}, i18nInitialProps);
  };

  return Extended;
});

/***/ }),

/***/ "./i18n.js":
/*!*****************!*\
  !*** ./i18n.js ***!
  \*****************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const i18next = __webpack_require__(/*! i18next */ "i18next");

const XHR = __webpack_require__(/*! i18next-xhr-backend */ "i18next-xhr-backend");

const LanguageDetector = __webpack_require__(/*! i18next-browser-languagedetector */ "i18next-browser-languagedetector");

const i18n = i18next.default ? i18next.default : i18next;
const options = {
  fallbackLng: 'en',
  load: 'languageOnly',
  // we only provide en, de -> no region specific locals like en-US, de-DE
  // have a common namespace used around the full app
  ns: ['common'],
  defaultNS: 'common',
  debug: false,
  // process.env.NODE_ENV !== 'production',
  saveMissing: true,
  interpolation: {
    escapeValue: false,
    // not needed for react!!
    formatSeparator: ',',
    format: (value, format, lng) => {
      if (format === 'uppercase') return value.toUpperCase();
      return value;
    }
  }
}; // for browser use xhr backend to load translations and browser lng detector

if (false) {} // initialize if not already initialized


if (!i18n.isInitialized) i18n.init(options); // a simple helper to getInitialProps passed on loaded i18n data

i18n.getInitialProps = (req, namespaces) => {
  if (!namespaces) namespaces = i18n.options.defaultNS;
  if (typeof namespaces === 'string') namespaces = [namespaces]; // do not serialize i18next instance avoid sending it to client

  if (req) req.i18n.toJSON = () => null;
  const ret = {
    i18n: req ? req.i18n : i18n // use the instance on req - fixed language on request (avoid issues in race conditions with lngs of different users)

  }; // for serverside pass down initial translations

  if (req) {
    const initialI18nStore = {};
    req.i18n.languages.forEach(l => {
      initialI18nStore[l] = {};
      namespaces.forEach(ns => {
        initialI18nStore[l][ns] = (req.i18n.services.resourceStore.data[l] || {})[ns] || {};
      });
    });
    ret.initialI18nStore = initialI18nStore;
    ret.initialLanguage = req.i18n.language;
  }

  return ret;
};

module.exports = i18n;

/***/ }),

/***/ "./lib/gtag.js":
/*!*********************!*\
  !*** ./lib/gtag.js ***!
  \*********************/
/*! exports provided: GA_TRACKING_ID, pageview, event */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GA_TRACKING_ID", function() { return GA_TRACKING_ID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pageview", function() { return pageview; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "event", function() { return event; });
const GA_TRACKING_ID = 'UA-92177881-2'; // https://developers.google.com/analytics/devguides/collection/gtagjs/pages

const pageview = url => {
  window.gtag('config', GA_TRACKING_ID, {
    page_location: url
  });
}; // https://developers.google.com/analytics/devguides/collection/gtagjs/events

const event = ({
  action,
  category,
  label,
  value
}) => {
  window.gtag('event', action, {
    event_category: category,
    event_label: label,
    value: value
  });
};

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/next/app.js":
/*!**********************************!*\
  !*** ./node_modules/next/app.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/pages/_app */ "./node_modules/next/dist/pages/_app.js")


/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/utils.js":
/*!*********************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/utils.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

const url_1 = __webpack_require__(/*! url */ "url");
/**
 * Utils
 */


function execOnce(fn) {
  let used = false;
  let result = null;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn.apply(this, args);
    }

    return result;
  };
}

exports.execOnce = execOnce;

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

exports.getLocationOrigin = getLocationOrigin;

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

exports.getURL = getURL;

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

exports.getDisplayName = getDisplayName;

function isResSent(res) {
  return res.finished || res.headersSent;
}

exports.isResSent = isResSent;

async function loadGetInitialProps(App, ctx) {
  var _a;

  if (true) {
    if ((_a = App.prototype) === null || _a === void 0 ? void 0 : _a.getInitialProps) {
      const message = `"${getDisplayName(App)}.getInitialProps()" is defined as an instance method - visit https://err.sh/zeit/next.js/get-initial-props-as-an-instance-method for more information.`;
      throw new Error(message);
    }
  } // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (true) {
    if (Object.keys(props).length === 0 && !ctx.ctx) {
      console.warn(`${getDisplayName(App)} returned an empty object from \`getInitialProps\`. This de-optimizes and prevents automatic static optimization. https://err.sh/zeit/next.js/empty-object-getInitialProps`);
    }
  }

  return props;
}

exports.loadGetInitialProps = loadGetInitialProps;
exports.urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];

function formatWithValidation(url, options) {
  if (true) {
    if (url !== null && typeof url === 'object') {
      Object.keys(url).forEach(key => {
        if (exports.urlObjectKeys.indexOf(key) === -1) {
          console.warn(`Unknown key passed via urlObject into url.format: ${key}`);
        }
      });
    }
  }

  return url_1.format(url, options);
}

exports.formatWithValidation = formatWithValidation;
exports.SP = typeof performance !== 'undefined';
exports.ST = exports.SP && typeof performance.mark === 'function' && typeof performance.measure === 'function';

/***/ }),

/***/ "./node_modules/next/dist/pages/_app.js":
/*!**********************************************!*\
  !*** ./node_modules/next/dist/pages/_app.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.Container = Container;
exports.createUrl = createUrl;
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _utils = __webpack_require__(/*! ../next-server/lib/utils */ "./node_modules/next/dist/next-server/lib/utils.js");

exports.AppInitialProps = _utils.AppInitialProps;
/**
* `App` component is used for initialize of pages. It allows for overwriting and full control of the `page` initialization.
* This allows for keeping state between navigation, custom error handling, injecting additional data.
*/

async function appGetInitialProps(_ref) {
  var {
    Component,
    ctx
  } = _ref;
  var pageProps = await (0, _utils.loadGetInitialProps)(Component, ctx);
  return {
    pageProps
  };
}

class App extends _react.default.Component {
  // Kept here for backwards compatibility.
  // When someone ended App they could call `super.componentDidCatch`.
  // @deprecated This method is no longer needed. Errors are caught at the top level
  componentDidCatch(error, _errorInfo) {
    throw error;
  }

  render() {
    var {
      router,
      Component,
      pageProps,
      __N_SSG,
      __N_SSP
    } = this.props;
    return _react.default.createElement(Component, Object.assign({}, pageProps, // we don't add the legacy URL prop if it's using non-legacy
    // methods like getStaticProps and getServerSideProps
    !(__N_SSG || __N_SSP) ? {
      url: createUrl(router)
    } : {}));
  }

}

exports.default = App;
App.origGetInitialProps = appGetInitialProps;
App.getInitialProps = appGetInitialProps;
var warnContainer;
var warnUrl;

if (true) {
  warnContainer = (0, _utils.execOnce)(() => {
    console.warn("Warning: the `Container` in `_app` has been deprecated and should be removed. https://err.sh/zeit/next.js/app-container-deprecated");
  });
  warnUrl = (0, _utils.execOnce)(() => {
    console.error("Warning: the 'url' property is deprecated. https://err.sh/zeit/next.js/url-deprecated");
  });
} // @deprecated noop for now until removal


function Container(p) {
  if (true) warnContainer();
  return p.children;
}

function createUrl(router) {
  // This is to make sure we don't references the router object at call time
  var {
    pathname,
    asPath,
    query
  } = router;
  return {
    get query() {
      if (true) warnUrl();
      return query;
    },

    get pathname() {
      if (true) warnUrl();
      return pathname;
    },

    get asPath() {
      if (true) warnUrl();
      return asPath;
    },

    back: () => {
      if (true) warnUrl();
      router.back();
    },
    push: (url, as) => {
      if (true) warnUrl();
      return router.push(url, as);
    },
    pushTo: (href, as) => {
      if (true) warnUrl();
      var pushRoute = as ? href : '';
      var pushUrl = as || href;
      return router.push(pushRoute, pushUrl);
    },
    replace: (url, as) => {
      if (true) warnUrl();
      return router.replace(url, as);
    },
    replaceTo: (href, as) => {
      if (true) warnUrl();
      var replaceRoute = as ? href : '';
      var replaceUrl = as || href;
      return router.replace(replaceRoute, replaceUrl);
    }
  };
}

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MyApp; });
/* harmony import */ var _components_alheimsins__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/alheimsins */ "./components/alheimsins/index.js");
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/app */ "./node_modules/next/app.js");
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_app__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../routes */ "./routes.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lib_gtag__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../lib/gtag */ "./lib/gtag.js");
var __jsx = react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement;






_routes__WEBPACK_IMPORTED_MODULE_3__["Router"].onRouteChangeComplete = url => _lib_gtag__WEBPACK_IMPORTED_MODULE_4__["pageview"](url);

class MyApp extends next_app__WEBPACK_IMPORTED_MODULE_1___default.a {
  static async getInitialProps({
    Component,
    router,
    ctx,
    ctx: {
      query,
      req
    }
  }) {
    let componentProps = {};
    const path = req && req.url ? req.url : false;
    const countryCode = req && req.requestCountryCode ? req.requestCountryCode.toLowerCase() : 'en'; // const ip = ctx && ctx.req ? ctx.req.socket.remoteAddress : false

    if (Component.getInitialProps) {
      componentProps = await Component.getInitialProps(ctx);
    }

    const pageProps = Object.assign({}, componentProps, {
      query,
      path,
      countryCode
    });
    return {
      pageProps
    };
  }

  render() {
    const {
      Component,
      pageProps
    } = this.props;
    return __jsx(_components_alheimsins__WEBPACK_IMPORTED_MODULE_0__["Layout"], null, __jsx(Component, pageProps));
  }

}

/***/ }),

/***/ "./routes.js":
/*!*******************!*\
  !*** ./routes.js ***!
  \*******************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const routes = module.exports = __webpack_require__(/*! next-routes */ "next-routes")();

routes.add('index', '/').add('about').add('test', '/test/:lang?').add('result', '/result').add('showResult', '/result/:id').add('compare', '/compare').add('showCompare', '/compare/:id', 'showCompare');

/***/ }),

/***/ 0:
/*!****************************************!*\
  !*** multi private-next-pages/_app.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! private-next-pages/_app.js */"./pages/_app.js");


/***/ }),

/***/ "i18next":
/*!**************************!*\
  !*** external "i18next" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("i18next");

/***/ }),

/***/ "i18next-browser-languagedetector":
/*!***************************************************!*\
  !*** external "i18next-browser-languagedetector" ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("i18next-browser-languagedetector");

/***/ }),

/***/ "i18next-xhr-backend":
/*!**************************************!*\
  !*** external "i18next-xhr-backend" ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("i18next-xhr-backend");

/***/ }),

/***/ "next-routes":
/*!******************************!*\
  !*** external "next-routes" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next-routes");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-i18next":
/*!********************************!*\
  !*** external "react-i18next" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-i18next");

/***/ }),

/***/ "react-icons/fa":
/*!*********************************!*\
  !*** external "react-icons/fa" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons/fa");

/***/ }),

/***/ "react-icons/md":
/*!*********************************!*\
  !*** external "react-icons/md" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons/md");

/***/ }),

/***/ "styled-jsx/style":
/*!***********************************!*\
  !*** external "styled-jsx/style" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("url");

/***/ })

/******/ });
//# sourceMappingURL=_app.js.map