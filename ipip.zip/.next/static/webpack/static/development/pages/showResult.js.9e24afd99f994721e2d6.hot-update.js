webpackHotUpdate("static\\development\\pages\\showResult.js",{

/***/ "./components/Domain.js":
/*!******************************!*\
  !*** ./components/Domain.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _default; });
/* harmony import */ var _babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _Summary__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Summary */ "./components/Summary.js");
/* harmony import */ var _alheimsins__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./alheimsins */ "./components/alheimsins/index.js");








var __jsx = react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement;

function _createSuper(Derived) { return function () { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__["default"])(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }





var Facet = function Facet(_ref) {
  var data = _ref.data;
  return __jsx(react__WEBPACK_IMPORTED_MODULE_7___default.a.Fragment, null, __jsx(_alheimsins__WEBPACK_IMPORTED_MODULE_9__["ShortcutH2"], {
    name: data.title
  }), __jsx("p", null, "Score: ", data.score, "/20 - ", data.scoreText), __jsx("p", null, __jsx("span", {
    dangerouslySetInnerHTML: {
      __html: data.text
    }
  })));
};

var _default = /*#__PURE__*/function (_Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__["default"])(_default, _Component);

  var _super = _createSuper(_default);

  function _default(props) {
    var _this;

    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__["default"])(this, _default);

    _this = _super.call(this, props);
    _this.state = {}; //this.readMore = this.readMore.bind(this)

    return _this;
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__["default"])(_default, [{
    key: "handleReadMore",
    value: function handleReadMore(e) {
      var name = e.currentTarget.getAttribute('name');
      var action = !this.state[name] || this.state[name] === 'none';
      this.setState(Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, name, action));
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          data = _this$props.data,
          chartWidth = _this$props.chartWidth;
      return __jsx("div", {
        className: "jsx-193341604" + " " + 'domain-wrapper'
      }, __jsx(_alheimsins__WEBPACK_IMPORTED_MODULE_9__["ShortcutH1"], {
        name: data.title
      }), __jsx("p", {
        className: "jsx-193341604"
      }, __jsx("em", {
        className: "jsx-193341604"
      }, data.shortDescription)), __jsx("p", {
        className: "jsx-193341604"
      }, "Score: ", data.score, "/120 - ", data.scoreText), __jsx("p", {
        className: "jsx-193341604"
      }, __jsx("strong", {
        className: "jsx-193341604"
      }, data.text)), __jsx("p", {
        className: "jsx-193341604"
      }, this.state[data.domain] ? __jsx(react__WEBPACK_IMPORTED_MODULE_7___default.a.Fragment, null, __jsx("span", {
        dangerouslySetInnerHTML: {
          __html: data.description
        },
        className: "jsx-193341604"
      }), __jsx("br", {
        className: "jsx-193341604"
      }), __jsx("br", {
        className: "jsx-193341604"
      }), __jsx("span", {
        name: data.domain,
        onClick: this.handleReadMore,
        style: {
          cursor: 'pointer'
        },
        className: "jsx-193341604"
      }, __jsx("a", {
        className: "jsx-193341604"
      }, "read less"))) : __jsx(react__WEBPACK_IMPORTED_MODULE_7___default.a.Fragment, null, __jsx("span", {
        dangerouslySetInnerHTML: {
          __html: data.description.substring(0, 100)
        },
        className: "jsx-193341604"
      }), __jsx("span", {
        name: data.domain,
        onClick: this.handleReadMore,
        style: {
          cursor: 'pointer'
        },
        className: "jsx-193341604"
      }, "... ", __jsx("a", {
        className: "jsx-193341604"
      }, "read more"), " (", data.description.split(' ').length, " words)"))), data && data.facets && __jsx(_Summary__WEBPACK_IMPORTED_MODULE_8__["default"], {
        data: data.facets,
        vAxis: {
          minValue: 0,
          maxValue: 20
        },
        title: data.title,
        chartWidth: chartWidth
      }), data && data.facets && data.facets.map(function (facet, index) {
        return __jsx(Facet, {
          data: facet,
          key: index
        });
      }), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_6___default.a, {
        id: "193341604"
      }, "span.jsx-193341604{margin-right:10px;}.domain-wrapper.jsx-193341604{box-shadow:0 2px 2px 0 rgba(0,0,0,.16),0 0 2px 0 rgba(0,0,0,.12);margin-top:10px;padding:10px;text-align:left;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXERvbWFpbi5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUEyQ1csQUFHaUMsQUFHZ0Qsa0JBRnBFLCtDQUdrQixnQkFDSCxhQUNHLGdCQUNsQiIsImZpbGUiOiJHOlxcZGV2XFxpcGlwXFxjb21wb25lbnRzXFxEb21haW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBTdW1tYXJ5IGZyb20gJy4vU3VtbWFyeSdcbmltcG9ydCB7IFNob3J0Y3V0SDIsIFNob3J0Y3V0SDEgfSBmcm9tICcuL2FsaGVpbXNpbnMnXG5cbmNvbnN0IEZhY2V0ID0gKHsgZGF0YSB9KSA9PiAoXG4gIDw+XG4gICAgPFNob3J0Y3V0SDIgbmFtZT17ZGF0YS50aXRsZX0gLz5cbiAgICA8cD5TY29yZToge2RhdGEuc2NvcmV9LzIwIC0ge2RhdGEuc2NvcmVUZXh0fTwvcD5cbiAgICA8cD48c3BhbiBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IGRhdGEudGV4dCB9fSAvPjwvcD5cbiAgPC8+XG4pXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGV4dGVuZHMgQ29tcG9uZW50IHtcbiAgY29uc3RydWN0b3IgKHByb3BzKSB7XG4gICAgc3VwZXIocHJvcHMpXG4gICAgdGhpcy5zdGF0ZSA9IHt9XG4gICAgLy90aGlzLnJlYWRNb3JlID0gdGhpcy5yZWFkTW9yZS5iaW5kKHRoaXMpXG4gIH1cblxuICBoYW5kbGVSZWFkTW9yZSAoZSkge1xuICAgIGNvbnN0IG5hbWUgPSBlLmN1cnJlbnRUYXJnZXQuZ2V0QXR0cmlidXRlKCduYW1lJylcbiAgICBjb25zdCBhY3Rpb24gPSAhdGhpcy5zdGF0ZVtuYW1lXSB8fCB0aGlzLnN0YXRlW25hbWVdID09PSAnbm9uZSdcbiAgICB0aGlzLnNldFN0YXRlKHsgW25hbWVdOiBhY3Rpb24gfSlcbiAgfVxuXG4gIHJlbmRlciAoKSB7XG4gICAgY29uc3QgeyBkYXRhLCBjaGFydFdpZHRoIH0gPSB0aGlzLnByb3BzXG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdkb21haW4td3JhcHBlcic+XG4gICAgICAgIDxTaG9ydGN1dEgxIG5hbWU9e2RhdGEudGl0bGV9IC8+XG4gICAgICAgIDxwPjxlbT57ZGF0YS5zaG9ydERlc2NyaXB0aW9ufTwvZW0+PC9wPlxuICAgICAgICA8cD5TY29yZToge2RhdGEuc2NvcmV9LzEyMCAtIHtkYXRhLnNjb3JlVGV4dH08L3A+XG4gICAgICAgIDxwPjxzdHJvbmc+e2RhdGEudGV4dH08L3N0cm9uZz48L3A+XG4gICAgICAgIDxwPlxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHRoaXMuc3RhdGVbZGF0YS5kb21haW5dXG4gICAgICAgICAgICAgID8gPD48c3BhbiBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IGRhdGEuZGVzY3JpcHRpb24gfX0gLz48YnIgLz48YnIgLz48c3BhbiBuYW1lPXtkYXRhLmRvbWFpbn0gb25DbGljaz17dGhpcy5oYW5kbGVSZWFkTW9yZX0gc3R5bGU9e3sgY3Vyc29yOiAncG9pbnRlcicgfX0+PGE+cmVhZCBsZXNzPC9hPjwvc3Bhbj48Lz5cbiAgICAgICAgICAgICAgOiA8PjxzcGFuIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7IF9faHRtbDogZGF0YS5kZXNjcmlwdGlvbi5zdWJzdHJpbmcoMCwgMTAwKSB9fSAvPjxzcGFuIG5hbWU9e2RhdGEuZG9tYWlufSBvbkNsaWNrPXt0aGlzLmhhbmRsZVJlYWRNb3JlfSBzdHlsZT17eyBjdXJzb3I6ICdwb2ludGVyJyB9fT4uLi4gPGE+cmVhZCBtb3JlPC9hPiAoe2RhdGEuZGVzY3JpcHRpb24uc3BsaXQoJyAnKS5sZW5ndGh9IHdvcmRzKTwvc3Bhbj48Lz5cbiAgICAgICAgICB9XG4gICAgICAgIDwvcD5cbiAgICAgICAge2RhdGEgJiYgZGF0YS5mYWNldHMgJiYgPFN1bW1hcnkgZGF0YT17ZGF0YS5mYWNldHN9IHZBeGlzPXt7IG1pblZhbHVlOiAwLCBtYXhWYWx1ZTogMjAgfX0gdGl0bGU9e2RhdGEudGl0bGV9IGNoYXJ0V2lkdGg9e2NoYXJ0V2lkdGh9IC8+fVxuICAgICAgICB7ZGF0YSAmJiBkYXRhLmZhY2V0cyAmJiBkYXRhLmZhY2V0cy5tYXAoKGZhY2V0LCBpbmRleCkgPT4gPEZhY2V0IGRhdGE9e2ZhY2V0fSBrZXk9e2luZGV4fSAvPil9XG4gICAgICAgIDxzdHlsZSBqc3g+XG4gICAgICAgICAge2BcbiAgICAgICAgICAgIHNwYW4ge1xuICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAuZG9tYWluLXdyYXBwZXIge1xuICAgICAgICAgICAgICBib3gtc2hhZG93OiAwIDJweCAycHggMCByZ2JhKDAsMCwwLC4xNiksIDAgMCAycHggMCByZ2JhKDAsMCwwLC4xMik7XG4gICAgICAgICAgICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgICAgICAgICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgICAgICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgYH1cbiAgICAgICAgPC9zdHlsZT5cbiAgICAgIDwvZGl2PlxuICAgIClcbiAgfVxufVxuIl19 */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\Domain.js */"));
    }
  }]);

  return _default;
}(react__WEBPACK_IMPORTED_MODULE_7__["Component"]);



/***/ })

})
//# sourceMappingURL=showResult.js.9e24afd99f994721e2d6.hot-update.js.map