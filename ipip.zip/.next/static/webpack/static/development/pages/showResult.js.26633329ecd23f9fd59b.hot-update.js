webpackHotUpdate("static\\development\\pages\\showResult.js",{

/***/ "./components/Domain.js":
/*!******************************!*\
  !*** ./components/Domain.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _default; });
/* harmony import */ var _babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _Summary__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Summary */ "./components/Summary.js");
/* harmony import */ var _alheimsins__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./alheimsins */ "./components/alheimsins/index.js");









var __jsx = react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement;

function _createSuper(Derived) { return function () { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__["default"])(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }





var Facet = function Facet(_ref) {
  var data = _ref.data;
  return __jsx(react__WEBPACK_IMPORTED_MODULE_8___default.a.Fragment, null, __jsx(_alheimsins__WEBPACK_IMPORTED_MODULE_10__["ShortcutH2"], {
    name: data.title
  }), __jsx("p", null, "Score: ", data.score, "/20 - ", data.scoreText), __jsx("p", null, __jsx("span", {
    dangerouslySetInnerHTML: {
      __html: data.text
    }
  })));
};

var _default = /*#__PURE__*/function (_Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__["default"])(_default, _Component);

  var _super = _createSuper(_default);

  function _default(props) {
    var _this;

    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__["default"])(this, _default);

    _this = _super.call(this, props);
    _this.state = {};
    _this.handleReadMore = _this.handleReadMore.bind(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__["default"])(_this));
    return _this;
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__["default"])(_default, [{
    key: "handleReadMore",
    value: function handleReadMore(e) {
      var name = e.currentTarget.getAttribute('name');
      var action = !this.state[name] || this.state[name] === 'none';
      this.setState(Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, name, action));
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          data = _this$props.data,
          chartWidth = _this$props.chartWidth;
      return __jsx("div", {
        className: "jsx-193341604" + " " + 'domain-wrapper'
      }, __jsx(_alheimsins__WEBPACK_IMPORTED_MODULE_10__["ShortcutH1"], {
        name: data.title
      }), __jsx("p", {
        className: "jsx-193341604"
      }, __jsx("em", {
        className: "jsx-193341604"
      }, data.shortDescription)), __jsx("p", {
        className: "jsx-193341604"
      }, "Score: ", data.score, "/120 - ", data.scoreText), __jsx("p", {
        className: "jsx-193341604"
      }, __jsx("strong", {
        className: "jsx-193341604"
      }, data.text)), __jsx("p", {
        className: "jsx-193341604"
      }, this.state[data.domain] ? __jsx(react__WEBPACK_IMPORTED_MODULE_8___default.a.Fragment, null, __jsx("span", {
        dangerouslySetInnerHTML: {
          __html: data.description
        },
        className: "jsx-193341604"
      }), __jsx("br", {
        className: "jsx-193341604"
      }), __jsx("br", {
        className: "jsx-193341604"
      }), __jsx("span", {
        name: data.domain,
        onClick: this.handleReadMore,
        style: {
          cursor: 'pointer'
        },
        className: "jsx-193341604"
      }, __jsx("a", {
        className: "jsx-193341604"
      }, "read less"))) : __jsx(react__WEBPACK_IMPORTED_MODULE_8___default.a.Fragment, null, __jsx("span", {
        dangerouslySetInnerHTML: {
          __html: data.description.substring(0, 100)
        },
        className: "jsx-193341604"
      }), __jsx("span", {
        name: data.domain,
        onClick: this.handleReadMore,
        style: {
          cursor: 'pointer'
        },
        className: "jsx-193341604"
      }, "... ", __jsx("a", {
        className: "jsx-193341604"
      }, "read more"), " (", data.description.split(' ').length, " words)"))), data && data.facets && __jsx(_Summary__WEBPACK_IMPORTED_MODULE_9__["default"], {
        data: data.facets,
        vAxis: {
          minValue: 0,
          maxValue: 20
        },
        title: data.title,
        chartWidth: chartWidth
      }), data && data.facets && data.facets.map(function (facet, index) {
        return __jsx(Facet, {
          data: facet,
          key: index
        });
      }), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_7___default.a, {
        id: "193341604"
      }, "span.jsx-193341604{margin-right:10px;}.domain-wrapper.jsx-193341604{box-shadow:0 2px 2px 0 rgba(0,0,0,.16),0 0 2px 0 rgba(0,0,0,.12);margin-top:10px;padding:10px;text-align:left;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkc6XFxkZXZcXGlwaXBcXGNvbXBvbmVudHNcXERvbWFpbi5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUEyQ1csQUFHaUMsQUFHZ0Qsa0JBRnBFLCtDQUdrQixnQkFDSCxhQUNHLGdCQUNsQiIsImZpbGUiOiJHOlxcZGV2XFxpcGlwXFxjb21wb25lbnRzXFxEb21haW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBTdW1tYXJ5IGZyb20gJy4vU3VtbWFyeSdcbmltcG9ydCB7IFNob3J0Y3V0SDIsIFNob3J0Y3V0SDEgfSBmcm9tICcuL2FsaGVpbXNpbnMnXG5cbmNvbnN0IEZhY2V0ID0gKHsgZGF0YSB9KSA9PiAoXG4gIDw+XG4gICAgPFNob3J0Y3V0SDIgbmFtZT17ZGF0YS50aXRsZX0gLz5cbiAgICA8cD5TY29yZToge2RhdGEuc2NvcmV9LzIwIC0ge2RhdGEuc2NvcmVUZXh0fTwvcD5cbiAgICA8cD48c3BhbiBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IGRhdGEudGV4dCB9fSAvPjwvcD5cbiAgPC8+XG4pXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGV4dGVuZHMgQ29tcG9uZW50IHtcbiAgY29uc3RydWN0b3IgKHByb3BzKSB7XG4gICAgc3VwZXIocHJvcHMpXG4gICAgdGhpcy5zdGF0ZSA9IHt9XG4gICAgdGhpcy5oYW5kbGVSZWFkTW9yZSA9IHRoaXMuaGFuZGxlUmVhZE1vcmUuYmluZCh0aGlzKVxuICB9XG5cbiAgaGFuZGxlUmVhZE1vcmUgKGUpIHtcbiAgICBjb25zdCBuYW1lID0gZS5jdXJyZW50VGFyZ2V0LmdldEF0dHJpYnV0ZSgnbmFtZScpXG4gICAgY29uc3QgYWN0aW9uID0gIXRoaXMuc3RhdGVbbmFtZV0gfHwgdGhpcy5zdGF0ZVtuYW1lXSA9PT0gJ25vbmUnXG4gICAgdGhpcy5zZXRTdGF0ZSh7IFtuYW1lXTogYWN0aW9uIH0pXG4gIH1cblxuICByZW5kZXIgKCkge1xuICAgIGNvbnN0IHsgZGF0YSwgY2hhcnRXaWR0aCB9ID0gdGhpcy5wcm9wc1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT0nZG9tYWluLXdyYXBwZXInPlxuICAgICAgICA8U2hvcnRjdXRIMSBuYW1lPXtkYXRhLnRpdGxlfSAvPlxuICAgICAgICA8cD48ZW0+e2RhdGEuc2hvcnREZXNjcmlwdGlvbn08L2VtPjwvcD5cbiAgICAgICAgPHA+U2NvcmU6IHtkYXRhLnNjb3JlfS8xMjAgLSB7ZGF0YS5zY29yZVRleHR9PC9wPlxuICAgICAgICA8cD48c3Ryb25nPntkYXRhLnRleHR9PC9zdHJvbmc+PC9wPlxuICAgICAgICA8cD5cbiAgICAgICAgICB7XG4gICAgICAgICAgICB0aGlzLnN0YXRlW2RhdGEuZG9tYWluXVxuICAgICAgICAgICAgICA/IDw+PHNwYW4gZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9e3sgX19odG1sOiBkYXRhLmRlc2NyaXB0aW9uIH19IC8+PGJyIC8+PGJyIC8+PHNwYW4gbmFtZT17ZGF0YS5kb21haW59IG9uQ2xpY2s9e3RoaXMuaGFuZGxlUmVhZE1vcmV9IHN0eWxlPXt7IGN1cnNvcjogJ3BvaW50ZXInIH19PjxhPnJlYWQgbGVzczwvYT48L3NwYW4+PC8+XG4gICAgICAgICAgICAgIDogPD48c3BhbiBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IGRhdGEuZGVzY3JpcHRpb24uc3Vic3RyaW5nKDAsIDEwMCkgfX0gLz48c3BhbiBuYW1lPXtkYXRhLmRvbWFpbn0gb25DbGljaz17dGhpcy5oYW5kbGVSZWFkTW9yZX0gc3R5bGU9e3sgY3Vyc29yOiAncG9pbnRlcicgfX0+Li4uIDxhPnJlYWQgbW9yZTwvYT4gKHtkYXRhLmRlc2NyaXB0aW9uLnNwbGl0KCcgJykubGVuZ3RofSB3b3Jkcyk8L3NwYW4+PC8+XG4gICAgICAgICAgfVxuICAgICAgICA8L3A+XG4gICAgICAgIHtkYXRhICYmIGRhdGEuZmFjZXRzICYmIDxTdW1tYXJ5IGRhdGE9e2RhdGEuZmFjZXRzfSB2QXhpcz17eyBtaW5WYWx1ZTogMCwgbWF4VmFsdWU6IDIwIH19IHRpdGxlPXtkYXRhLnRpdGxlfSBjaGFydFdpZHRoPXtjaGFydFdpZHRofSAvPn1cbiAgICAgICAge2RhdGEgJiYgZGF0YS5mYWNldHMgJiYgZGF0YS5mYWNldHMubWFwKChmYWNldCwgaW5kZXgpID0+IDxGYWNldCBkYXRhPXtmYWNldH0ga2V5PXtpbmRleH0gLz4pfVxuICAgICAgICA8c3R5bGUganN4PlxuICAgICAgICAgIHtgXG4gICAgICAgICAgICBzcGFuIHtcbiAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLmRvbWFpbi13cmFwcGVyIHtcbiAgICAgICAgICAgICAgYm94LXNoYWRvdzogMCAycHggMnB4IDAgcmdiYSgwLDAsMCwuMTYpLCAwIDAgMnB4IDAgcmdiYSgwLDAsMCwuMTIpO1xuICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgICBwYWRkaW5nOiAxMHB4O1xuICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgICAgICAgICAgfVxuICAgICAgICAgIGB9XG4gICAgICAgIDwvc3R5bGU+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cbn1cbiJdfQ== */\n/*@ sourceURL=G:\\\\dev\\\\ipip\\\\components\\\\Domain.js */"));
    }
  }]);

  return _default;
}(react__WEBPACK_IMPORTED_MODULE_8__["Component"]);



/***/ })

})
//# sourceMappingURL=showResult.js.26633329ecd23f9fd59b.hot-update.js.map